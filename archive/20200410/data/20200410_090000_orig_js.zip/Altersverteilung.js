var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":298},{"label":"15-24","y":1242},{"label":"25-34","y":1878},{"label":"35-44","y":1883},{"label":"45-54","y":2830},{"label":"55-64","y":2247},{"label":">64","y":2862}];
var AltersverteilungVersion = "10.04.2020 09:00:00 V 1.1.0.0"
