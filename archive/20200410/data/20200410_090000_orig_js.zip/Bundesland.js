var dpBundesland = [{"label":"W","y":1924},{"label":"Vbg","y":801},{"label":"T","y":3060},{"label":"Stmk","y":1471},{"label":"Sbg","y":1144},{"label":"OÖ","y":2089},{"label":"NÖ","y":2203},{"label":"Ktn","y":366},{"label":"Bgld","y":248}];
var BundeslandVersion = "10.04.2020 09:00:00 V 1.1.0.0"
