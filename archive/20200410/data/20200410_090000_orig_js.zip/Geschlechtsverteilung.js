var dpGeschlechtsverteilung = [{"label":"männlich","y":50},{"label":"weiblich","y":50}];
var GeschlechtsverteilungVersion = "10.04.2020 09:00:00 V 1.1.0.0"
