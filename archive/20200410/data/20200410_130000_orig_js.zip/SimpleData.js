var Erkrankungen = "13431";
var LetzteAktualisierung = "10.04.2020 13:00.00";
var SimpleDataVersion = "10.04.2020 13:00:00 V 1.1.0.0"
