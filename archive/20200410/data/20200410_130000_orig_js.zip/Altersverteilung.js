var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":302},{"label":"15-24","y":1263},{"label":"25-34","y":1891},{"label":"35-44","y":1903},{"label":"45-54","y":2850},{"label":"55-64","y":2269},{"label":">64","y":2887}];
var AltersverteilungVersion = "10.04.2020 13:00:00 V 1.1.0.0"
