var Erkrankungen = "13560";
var LetzteAktualisierung = "10.04.2020 22:59.59";
var SimpleDataVersion = "10.04.2020 22:59:59 V 1.1.0.0"
