var dpBundesland = [{"label":"W","y":1925},{"label":"Vbg","y":801},{"label":"T","y":3045},{"label":"Stmk","y":1468},{"label":"Sbg","y":1143},{"label":"OÖ","y":2085},{"label":"NÖ","y":2192},{"label":"Ktn","y":366},{"label":"Bgld","y":246}];
var BundeslandVersion = "10.04.2020 08:00:00 V 1.1.0.0"
