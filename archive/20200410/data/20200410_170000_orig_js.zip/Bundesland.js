var dpBundesland = [{"label":"W","y":1954},{"label":"Vbg","y":809},{"label":"T","y":3169},{"label":"Stmk","y":1493},{"label":"Sbg","y":1152},{"label":"OÖ","y":2106},{"label":"NÖ","y":2211},{"label":"Ktn","y":373},{"label":"Bgld","y":253}];
var BundeslandVersion = "10.04.2020 17:00:00 V 1.1.0.0"
