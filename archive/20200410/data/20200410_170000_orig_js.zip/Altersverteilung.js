var dpAltersverteilung = [{"label":"<5","y":68},{"label":"5-14","y":304},{"label":"15-24","y":1270},{"label":"25-34","y":1898},{"label":"35-44","y":1911},{"label":"45-54","y":2866},{"label":"55-64","y":2282},{"label":">64","y":2921}];
var AltersverteilungVersion = "10.04.2020 17:00:00 V 1.1.0.0"
