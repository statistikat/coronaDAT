var dpBundesland = [{"label":"W","y":1941},{"label":"Vbg","y":809},{"label":"T","y":3154},{"label":"Stmk","y":1476},{"label":"Sbg","y":1145},{"label":"OÖ","y":2098},{"label":"NÖ","y":2205},{"label":"Ktn","y":372},{"label":"Bgld","y":253}];
var BundeslandVersion = "10.04.2020 14:00:00 V 1.1.0.0"
