var dpAltersverteilung = [{"label":"<5","y":68},{"label":"5-14","y":303},{"label":"15-24","y":1264},{"label":"25-34","y":1893},{"label":"35-44","y":1905},{"label":"45-54","y":2855},{"label":"55-64","y":2271},{"label":">64","y":2894}];
var AltersverteilungVersion = "10.04.2020 14:00:00 V 1.1.0.0"
