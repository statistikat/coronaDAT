var dpBundesland = [{"label":"W","y":1926},{"label":"Vbg","y":808},{"label":"T","y":3118},{"label":"Stmk","y":1470},{"label":"Sbg","y":1145},{"label":"OÖ","y":2091},{"label":"NÖ","y":2203},{"label":"Ktn","y":366},{"label":"Bgld","y":250}];
var BundeslandVersion = "10.04.2020 11:00:00 V 1.1.0.0"
