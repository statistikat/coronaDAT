var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":298},{"label":"15-24","y":1255},{"label":"25-34","y":1883},{"label":"35-44","y":1895},{"label":"45-54","y":2843},{"label":"55-64","y":2262},{"label":">64","y":2875}];
var AltersverteilungVersion = "10.04.2020 11:00:00 V 1.1.0.0"
