var Erkrankungen = "13551";
var LetzteAktualisierung = "10.04.2020 20:00.00";
var SimpleDataVersion = "10.04.2020 20:00:00 V 1.1.0.0"
