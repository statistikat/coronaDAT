var dpAltersverteilung = [{"label":"<5","y":68},{"label":"5-14","y":304},{"label":"15-24","y":1270},{"label":"25-34","y":1900},{"label":"35-44","y":1915},{"label":"45-54","y":2869},{"label":"55-64","y":2284},{"label":">64","y":2921}];
var AltersverteilungVersion = "10.04.2020 18:00:00 V 1.1.0.0"
