var dpBundesland = [{"label":"W","y":1953},{"label":"Vbg","y":818},{"label":"T","y":3170},{"label":"Stmk","y":1493},{"label":"Sbg","y":1152},{"label":"OÖ","y":2106},{"label":"NÖ","y":2212},{"label":"Ktn","y":373},{"label":"Bgld","y":254}];
var BundeslandVersion = "10.04.2020 18:00:00 V 1.1.0.0"
