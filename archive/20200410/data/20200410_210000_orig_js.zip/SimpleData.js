var Erkrankungen = "13555";
var LetzteAktualisierung = "10.04.2020 21:00.00";
var SimpleDataVersion = "10.04.2020 21:00:00 V 1.1.0.0"
