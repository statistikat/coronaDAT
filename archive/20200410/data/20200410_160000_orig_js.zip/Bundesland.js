var dpBundesland = [{"label":"W","y":1952},{"label":"Vbg","y":809},{"label":"T","y":3164},{"label":"Stmk","y":1484},{"label":"Sbg","y":1152},{"label":"OÖ","y":2100},{"label":"NÖ","y":2207},{"label":"Ktn","y":373},{"label":"Bgld","y":253}];
var BundeslandVersion = "10.04.2020 16:00:00 V 1.1.0.0"
