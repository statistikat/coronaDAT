var dpAltersverteilung = [{"label":"<5","y":68},{"label":"5-14","y":304},{"label":"15-24","y":1269},{"label":"25-34","y":1893},{"label":"35-44","y":1910},{"label":"45-54","y":2864},{"label":"55-64","y":2276},{"label":">64","y":2910}];
var AltersverteilungVersion = "10.04.2020 16:00:00 V 1.1.0.0"
