var Erkrankungen = "13494";
var LetzteAktualisierung = "10.04.2020 16:00.00";
var SimpleDataVersion = "10.04.2020 16:00:00 V 1.1.0.0"
