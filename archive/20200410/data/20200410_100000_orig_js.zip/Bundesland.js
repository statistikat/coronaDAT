var dpBundesland = [{"label":"W","y":1924},{"label":"Vbg","y":805},{"label":"T","y":3086},{"label":"Stmk","y":1470},{"label":"Sbg","y":1146},{"label":"OÖ","y":2089},{"label":"NÖ","y":2203},{"label":"Ktn","y":366},{"label":"Bgld","y":248}];
var BundeslandVersion = "10.04.2020 10:00:00 V 1.1.0.0"
