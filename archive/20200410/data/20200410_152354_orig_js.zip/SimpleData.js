var Erkrankungen = "13492";
var LetzteAktualisierung = "10.04.2020 15:23.54";
var SimpleDataVersion = "10.04.2020 15:23:54 V 1.1.0.0"
