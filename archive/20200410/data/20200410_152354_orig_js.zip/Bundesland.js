var dpBundesland = [{"label":"W","y":1952},{"label":"Vbg","y":809},{"label":"T","y":3163},{"label":"Stmk","y":1484},{"label":"Sbg","y":1152},{"label":"OÖ","y":2100},{"label":"NÖ","y":2206},{"label":"Ktn","y":373},{"label":"Bgld","y":253}];
var BundeslandVersion = "10.04.2020 15:23:54 V 1.1.0.0"
