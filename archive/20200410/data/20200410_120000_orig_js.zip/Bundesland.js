var dpBundesland = [{"label":"W","y":1932},{"label":"Vbg","y":808},{"label":"T","y":3126},{"label":"Stmk","y":1474},{"label":"Sbg","y":1145},{"label":"OÖ","y":2094},{"label":"NÖ","y":2203},{"label":"Ktn","y":366},{"label":"Bgld","y":250}];
var BundeslandVersion = "10.04.2020 12:00:00 V 1.1.0.0"
