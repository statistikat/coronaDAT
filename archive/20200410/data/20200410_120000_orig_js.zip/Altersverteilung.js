var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":299},{"label":"15-24","y":1258},{"label":"25-34","y":1887},{"label":"35-44","y":1896},{"label":"45-54","y":2847},{"label":"55-64","y":2263},{"label":">64","y":2882}];
var AltersverteilungVersion = "10.04.2020 12:00:00 V 1.1.0.0"
