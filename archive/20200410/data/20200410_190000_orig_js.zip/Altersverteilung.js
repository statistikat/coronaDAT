var dpAltersverteilung = [{"label":"<5","y":68},{"label":"5-14","y":304},{"label":"15-24","y":1271},{"label":"25-34","y":1901},{"label":"35-44","y":1916},{"label":"45-54","y":2873},{"label":"55-64","y":2286},{"label":">64","y":2930}];
var AltersverteilungVersion = "10.04.2020 19:00:00 V 1.1.0.0"
