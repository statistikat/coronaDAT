var Erkrankungen = 8536;
var LetzteAktualisierung = "29.03.2020 15:00.00";
