var Erkrankungen = 8395;
var LetzteAktualisierung = "29.03.2020 11:00.00";
