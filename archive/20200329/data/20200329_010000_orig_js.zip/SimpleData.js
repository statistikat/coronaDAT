var Erkrankungen = 8280;
var LetzteAktualisierung = "29.03.2020 01:00.00";
