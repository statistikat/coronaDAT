var Erkrankungen = 8672;
var LetzteAktualisierung = "29.03.2020 18:00.00";
