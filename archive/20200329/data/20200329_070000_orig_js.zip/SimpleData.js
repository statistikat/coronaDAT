var Erkrankungen = 8280;
var LetzteAktualisierung = "29.03.2020 07:00.00";
