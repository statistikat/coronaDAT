var Erkrankungen = 8346;
var LetzteAktualisierung = "29.03.2020 10:00.00";
