var Erkrankungen = 8280;
var LetzteAktualisierung = "29.03.2020 05:00.00";
