var Erkrankungen = 8743;
var LetzteAktualisierung = "29.03.2020 21:00.00";
