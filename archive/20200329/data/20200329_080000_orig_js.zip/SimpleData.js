var Erkrankungen = 8291;
var LetzteAktualisierung = "29.03.2020 08:00.00";
