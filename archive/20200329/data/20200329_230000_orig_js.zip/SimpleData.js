var Erkrankungen = 8774;
var LetzteAktualisierung = "29.03.2020 23:00.00";
