var Erkrankungen = 8711;
var LetzteAktualisierung = "29.03.2020 19:00.00";
