var Erkrankungen = 8648;
var LetzteAktualisierung = "29.03.2020 17:00.00";
