var Erkrankungen = 8280;
var LetzteAktualisierung = "29.03.2020 03:00.00";
