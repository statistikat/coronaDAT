var Erkrankungen = 8305;
var LetzteAktualisierung = "29.03.2020 09:00.00";
