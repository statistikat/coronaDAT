var Erkrankungen = 8450;
var LetzteAktualisierung = "29.03.2020 13:00.00";
