var Erkrankungen = 8581;
var LetzteAktualisierung = "29.03.2020 16:00.00";
