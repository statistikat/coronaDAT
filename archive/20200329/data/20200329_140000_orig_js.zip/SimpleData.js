var Erkrankungen = 8486;
var LetzteAktualisierung = "29.03.2020 14:00.00";
