var Erkrankungen = 8411;
var LetzteAktualisierung = "29.03.2020 12:00.00";
