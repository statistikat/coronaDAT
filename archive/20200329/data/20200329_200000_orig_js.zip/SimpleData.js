var Erkrankungen = 8733;
var LetzteAktualisierung = "29.03.2020 20:00.00";
