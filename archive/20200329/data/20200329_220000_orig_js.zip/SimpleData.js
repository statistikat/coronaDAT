var Erkrankungen = 8760;
var LetzteAktualisierung = "29.03.2020 22:00.00";
