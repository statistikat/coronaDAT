var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":230},{"label":"15-24","y":979},{"label":"25-34","y":1541},{"label":"35-44","y":1562},{"label":"45-54","y":2263},{"label":"55-64","y":1835},{"label":">64","y":2180}];
var AltersverteilungVersion = "01.04.2020 19:00:00 V 1.1.0.0"
