var dpAltersverteilung = [{"label":"<5","y":41},{"label":"5-14","y":220},{"label":"15-24","y":943},{"label":"25-34","y":1489},{"label":"35-44","y":1501},{"label":"45-54","y":2166},{"label":"55-64","y":1762},{"label":">64","y":2060}];
var AltersverteilungVersion = "01.04.2020 05:00:00 V 1.1.0.0"
