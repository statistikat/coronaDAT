var dpBundesland = [{"label":"W","y":1458},{"label":"Vbg","y":666},{"label":"T","y":2403},{"label":"Stmk","y":1085},{"label":"Sbg","y":951},{"label":"OÖ","y":1657},{"label":"NÖ","y":1677},{"label":"Ktn","y":288},{"label":"Bgld","y":187}];
var BundeslandVersion = "01.04.2020 11:00:00 V 1.1.0.0"
