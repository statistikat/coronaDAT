var dpAltersverteilung = [{"label":"<5","y":42},{"label":"5-14","y":223},{"label":"15-24","y":961},{"label":"25-34","y":1511},{"label":"35-44","y":1520},{"label":"45-54","y":2203},{"label":"55-64","y":1795},{"label":">64","y":2117}];
var AltersverteilungVersion = "01.04.2020 11:00:00 V 1.1.0.0"
