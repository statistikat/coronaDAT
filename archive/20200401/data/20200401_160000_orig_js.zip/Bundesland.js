var dpBundesland = [{"label":"W","y":1497},{"label":"Vbg","y":669},{"label":"T","y":2422},{"label":"Stmk","y":1119},{"label":"Sbg","y":955},{"label":"OÖ","y":1671},{"label":"NÖ","y":1686},{"label":"Ktn","y":294},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 16:00:00 V 1.1.0.0"
