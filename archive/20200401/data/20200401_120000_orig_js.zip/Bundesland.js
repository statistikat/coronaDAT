var dpBundesland = [{"label":"W","y":1461},{"label":"Vbg","y":666},{"label":"T","y":2404},{"label":"Stmk","y":1085},{"label":"Sbg","y":950},{"label":"OÖ","y":1662},{"label":"NÖ","y":1683},{"label":"Ktn","y":289},{"label":"Bgld","y":187}];
var BundeslandVersion = "01.04.2020 12:00:00 V 1.1.0.0"
