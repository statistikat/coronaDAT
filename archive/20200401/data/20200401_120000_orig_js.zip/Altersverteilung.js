var dpAltersverteilung = [{"label":"<5","y":42},{"label":"5-14","y":224},{"label":"15-24","y":964},{"label":"25-34","y":1511},{"label":"35-44","y":1523},{"label":"45-54","y":2205},{"label":"55-64","y":1796},{"label":">64","y":2122}];
var AltersverteilungVersion = "01.04.2020 12:00:00 V 1.1.0.0"
