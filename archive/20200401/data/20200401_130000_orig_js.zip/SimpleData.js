var Erkrankungen = "10418";
var LetzteAktualisierung = "01.04.2020 13:00.00";
var SimpleDataVersion = "01.04.2020 13:00:00 V 1.1.0.0"
