var dpBundesland = [{"label":"W","y":1474},{"label":"Vbg","y":666},{"label":"T","y":2410},{"label":"Stmk","y":1093},{"label":"Sbg","y":950},{"label":"OÖ","y":1662},{"label":"NÖ","y":1685},{"label":"Ktn","y":290},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 13:00:00 V 1.1.0.0"
