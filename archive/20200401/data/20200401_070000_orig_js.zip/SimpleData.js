var Erkrankungen = "10185";
var LetzteAktualisierung = "01.04.2020 07:00.00";
var SimpleDataVersion = "01.04.2020 07:00:00 V 1.1.0.0"
