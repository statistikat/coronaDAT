var Erkrankungen = "10711";
var LetzteAktualisierung = "01.04.2020 23:00.00";
var SimpleDataVersion = "01.04.2020 23:00:00 V 1.1.0.0"
