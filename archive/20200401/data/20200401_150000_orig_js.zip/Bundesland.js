var dpBundesland = [{"label":"W","y":1497},{"label":"Vbg","y":666},{"label":"T","y":2414},{"label":"Stmk","y":1113},{"label":"Sbg","y":955},{"label":"OÖ","y":1671},{"label":"NÖ","y":1685},{"label":"Ktn","y":293},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 15:00:00 V 1.1.0.0"
