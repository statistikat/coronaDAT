var dpAltersverteilung = [{"label":"<5","y":43},{"label":"5-14","y":226},{"label":"15-24","y":966},{"label":"25-34","y":1525},{"label":"35-44","y":1539},{"label":"45-54","y":2222},{"label":"55-64","y":1815},{"label":">64","y":2146}];
var AltersverteilungVersion = "01.04.2020 15:00:00 V 1.1.0.0"
