var dpAltersverteilung = [{"label":"<5","y":44},{"label":"5-14","y":228},{"label":"15-24","y":973},{"label":"25-34","y":1538},{"label":"35-44","y":1555},{"label":"45-54","y":2249},{"label":"55-64","y":1828},{"label":">64","y":2170}];
var AltersverteilungVersion = "01.04.2020 18:00:00 V 1.1.0.0"
