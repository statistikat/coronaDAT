var dpBundesland = [{"label":"W","y":1529},{"label":"Vbg","y":669},{"label":"T","y":2434},{"label":"Stmk","y":1120},{"label":"Sbg","y":967},{"label":"OÖ","y":1698},{"label":"NÖ","y":1687},{"label":"Ktn","y":293},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 18:00:00 V 1.1.0.0"
