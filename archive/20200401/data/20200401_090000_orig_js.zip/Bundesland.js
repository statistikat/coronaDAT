var dpBundesland = [{"label":"W","y":1435},{"label":"Vbg","y":665},{"label":"T","y":2388},{"label":"Stmk","y":1085},{"label":"Sbg","y":949},{"label":"OÖ","y":1656},{"label":"NÖ","y":1655},{"label":"Ktn","y":278},{"label":"Bgld","y":187}];
var BundeslandVersion = "01.04.2020 09:00:00 V 1.1.0.0"
