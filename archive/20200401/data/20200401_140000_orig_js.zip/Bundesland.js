var dpBundesland = [{"label":"W","y":1486},{"label":"Vbg","y":666},{"label":"T","y":2412},{"label":"Stmk","y":1098},{"label":"Sbg","y":950},{"label":"OÖ","y":1665},{"label":"NÖ","y":1685},{"label":"Ktn","y":294},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 14:00:00 V 1.1.0.0"
