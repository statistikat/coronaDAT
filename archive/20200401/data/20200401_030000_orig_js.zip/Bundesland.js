var dpBundesland = [{"label":"W","y":1417},{"label":"Vbg","y":659},{"label":"T","y":2360},{"label":"Stmk","y":1063},{"label":"Sbg","y":949},{"label":"OÖ","y":1635},{"label":"NÖ","y":1636},{"label":"Ktn","y":278},{"label":"Bgld","y":185}];
var BundeslandVersion = "01.04.2020 03:00:00 V 1.1.0.0"
