var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":234},{"label":"15-24","y":986},{"label":"25-34","y":1545},{"label":"35-44","y":1565},{"label":"45-54","y":2271},{"label":"55-64","y":1844},{"label":">64","y":2188}];
var AltersverteilungVersion = "01.04.2020 22:00:00 V 1.1.0.0"
