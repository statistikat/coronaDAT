var dpBundesland = [{"label":"W","y":1505},{"label":"Vbg","y":669},{"label":"T","y":2434},{"label":"Stmk","y":1119},{"label":"Sbg","y":967},{"label":"OÖ","y":1691},{"label":"NÖ","y":1686},{"label":"Ktn","y":294},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 17:00:00 V 1.1.0.0"
