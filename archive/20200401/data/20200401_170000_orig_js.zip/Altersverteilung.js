var dpAltersverteilung = [{"label":"<5","y":44},{"label":"5-14","y":228},{"label":"15-24","y":970},{"label":"25-34","y":1534},{"label":"35-44","y":1548},{"label":"45-54","y":2242},{"label":"55-64","y":1825},{"label":">64","y":2162}];
var AltersverteilungVersion = "01.04.2020 17:00:00 V 1.1.0.0"
