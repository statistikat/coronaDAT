var Erkrankungen = "10663";
var LetzteAktualisierung = "01.04.2020 20:00.00";
var SimpleDataVersion = "01.04.2020 20:00:00 V 1.1.0.0"
