var dpBundesland = [{"label":"W","y":1546},{"label":"Vbg","y":671},{"label":"T","y":2452},{"label":"Stmk","y":1125},{"label":"Sbg","y":973},{"label":"OÖ","y":1728},{"label":"NÖ","y":1687},{"label":"Ktn","y":293},{"label":"Bgld","y":188}];
var BundeslandVersion = "01.04.2020 20:00:00 V 1.1.0.0"
