var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":234},{"label":"15-24","y":985},{"label":"25-34","y":1543},{"label":"35-44","y":1564},{"label":"45-54","y":2266},{"label":"55-64","y":1839},{"label":">64","y":2186}];
var AltersverteilungVersion = "01.04.2020 20:00:00 V 1.1.0.0"
