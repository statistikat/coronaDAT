var dpBundesland = [{"label":"W","y":1712},{"label":"Vbg","y":746},{"label":"T","y":2756},{"label":"Stmk","y":1312},{"label":"Sbg","y":1077},{"label":"OÖ","y":1955},{"label":"NÖ","y":1942},{"label":"Ktn","y":330},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 10:00:00 V 1.1.0.0"
