var dpBundesland = [{"label":"W","y":1712},{"label":"Vbg","y":746},{"label":"T","y":2742},{"label":"Stmk","y":1312},{"label":"Sbg","y":1079},{"label":"OÖ","y":1954},{"label":"NÖ","y":1931},{"label":"Ktn","y":322},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 09:00:00 V 1.1.0.0"
