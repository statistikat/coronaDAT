var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":278},{"label":"15-24","y":1119},{"label":"25-34","y":1728},{"label":"35-44","y":1737},{"label":"45-54","y":2565},{"label":"55-64","y":2044},{"label":">64","y":2501}];
var AltersverteilungVersion = "06.04.2020 09:00:00 V 1.1.0.0"
