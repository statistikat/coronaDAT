var dpBundesland = [{"label":"W","y":1755},{"label":"Vbg","y":756},{"label":"T","y":2780},{"label":"Stmk","y":1349},{"label":"Sbg","y":1085},{"label":"OÖ","y":1971},{"label":"NÖ","y":2004},{"label":"Ktn","y":329},{"label":"Bgld","y":232}];
var BundeslandVersion = "06.04.2020 17:00:00 V 1.1.0.0"
