var dpBundesland = [{"label":"W","y":1759},{"label":"Vbg","y":756},{"label":"T","y":2781},{"label":"Stmk","y":1349},{"label":"Sbg","y":1085},{"label":"OÖ","y":1971},{"label":"NÖ","y":2005},{"label":"Ktn","y":329},{"label":"Bgld","y":232}];
var BundeslandVersion = "06.04.2020 18:00:00 V 1.1.0.0"
