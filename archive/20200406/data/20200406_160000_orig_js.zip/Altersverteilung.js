var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":283},{"label":"15-24","y":1129},{"label":"25-34","y":1754},{"label":"35-44","y":1764},{"label":"45-54","y":2602},{"label":"55-64","y":2084},{"label":">64","y":2566}];
var AltersverteilungVersion = "06.04.2020 16:00:00 V 1.1.0.0"
