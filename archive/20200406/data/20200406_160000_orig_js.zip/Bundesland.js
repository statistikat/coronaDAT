var dpBundesland = [{"label":"W","y":1744},{"label":"Vbg","y":756},{"label":"T","y":2778},{"label":"Stmk","y":1346},{"label":"Sbg","y":1083},{"label":"OÖ","y":1964},{"label":"NÖ","y":2004},{"label":"Ktn","y":330},{"label":"Bgld","y":231}];
var BundeslandVersion = "06.04.2020 16:00:00 V 1.1.0.0"
