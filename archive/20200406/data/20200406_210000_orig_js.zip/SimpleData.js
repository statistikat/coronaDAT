var Erkrankungen = "12293";
var LetzteAktualisierung = "06.04.2020 21:00.00";
var SimpleDataVersion = "06.04.2020 21:00:00 V 1.1.0.0"
