var dpBundesland = [{"label":"W","y":1735},{"label":"Vbg","y":746},{"label":"T","y":2767},{"label":"Stmk","y":1338},{"label":"Sbg","y":1077},{"label":"OÖ","y":1962},{"label":"NÖ","y":1977},{"label":"Ktn","y":332},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 14:00:00 V 1.1.0.0"
