var dpBundesland = [{"label":"W","y":1716},{"label":"Vbg","y":746},{"label":"T","y":2758},{"label":"Stmk","y":1312},{"label":"Sbg","y":1077},{"label":"OÖ","y":1956},{"label":"NÖ","y":1949},{"label":"Ktn","y":330},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 11:00:00 V 1.1.0.0"
