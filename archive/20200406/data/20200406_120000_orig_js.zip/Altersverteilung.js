var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":280},{"label":"15-24","y":1122},{"label":"25-34","y":1736},{"label":"35-44","y":1748},{"label":"45-54","y":2576},{"label":"55-64","y":2052},{"label":">64","y":2515}];
var AltersverteilungVersion = "06.04.2020 12:00:00 V 1.1.0.0"
