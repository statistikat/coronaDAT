var dpBundesland = [{"label":"W","y":1719},{"label":"Vbg","y":746},{"label":"T","y":2763},{"label":"Stmk","y":1310},{"label":"Sbg","y":1077},{"label":"OÖ","y":1958},{"label":"NÖ","y":1952},{"label":"Ktn","y":330},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 12:00:00 V 1.1.0.0"
