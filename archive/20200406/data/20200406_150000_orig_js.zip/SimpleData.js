var Erkrankungen = "12206";
var LetzteAktualisierung = "06.04.2020 15:00.00";
var SimpleDataVersion = "06.04.2020 15:00:00 V 1.1.0.0"
