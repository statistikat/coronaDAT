var dpBundesland = [{"label":"W","y":1743},{"label":"Vbg","y":754},{"label":"T","y":2774},{"label":"Stmk","y":1339},{"label":"Sbg","y":1083},{"label":"OÖ","y":1963},{"label":"NÖ","y":1994},{"label":"Ktn","y":328},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 15:00:00 V 1.1.0.0"
