var dpBundesland = [{"label":"W","y":1704},{"label":"Vbg","y":746},{"label":"T","y":2739},{"label":"Stmk","y":1312},{"label":"Sbg","y":1079},{"label":"OÖ","y":1953},{"label":"NÖ","y":1903},{"label":"Ktn","y":319},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 03:00:00 V 1.1.0.0"
