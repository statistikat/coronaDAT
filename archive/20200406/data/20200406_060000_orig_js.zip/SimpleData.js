var Erkrankungen = "11983";
var LetzteAktualisierung = "06.04.2020 06:00.00";
var SimpleDataVersion = "06.04.2020 06:00:00 V 1.1.0.0"
