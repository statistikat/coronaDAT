var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":276},{"label":"15-24","y":1114},{"label":"25-34","y":1724},{"label":"35-44","y":1734},{"label":"45-54","y":2557},{"label":"55-64","y":2044},{"label":">64","y":2480}];
var AltersverteilungVersion = "06.04.2020 06:00:00 V 1.1.0.0"
