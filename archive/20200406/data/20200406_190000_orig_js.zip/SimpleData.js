var Erkrankungen = "12280";
var LetzteAktualisierung = "06.04.2020 19:00.00";
var SimpleDataVersion = "06.04.2020 19:00:00 V 1.1.0.0"
