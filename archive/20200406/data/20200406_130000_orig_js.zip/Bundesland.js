var dpBundesland = [{"label":"W","y":1719},{"label":"Vbg","y":746},{"label":"T","y":2766},{"label":"Stmk","y":1323},{"label":"Sbg","y":1077},{"label":"OÖ","y":1959},{"label":"NÖ","y":1959},{"label":"Ktn","y":332},{"label":"Bgld","y":228}];
var BundeslandVersion = "06.04.2020 13:00:00 V 1.1.0.0"
