var Erkrankungen = "12640";
var LetzteAktualisierung = "08.04.2020 03:00.00";
var SimpleDataVersion = "08.04.2020 03:00:00 V 1.1.0.0"
