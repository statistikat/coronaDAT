var dpBundesland = [{"label":"W","y":1831},{"label":"Vbg","y":792},{"label":"T","y":2891},{"label":"Stmk","y":1414},{"label":"Sbg","y":1119},{"label":"OÖ","y":2034},{"label":"NÖ","y":2113},{"label":"Ktn","y":346},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 13:00:00 V 1.1.0.0"
