var Erkrankungen = "12937";
var LetzteAktualisierung = "08.04.2020 21:00.00";
var SimpleDataVersion = "08.04.2020 21:00:00 V 1.1.0.0"
