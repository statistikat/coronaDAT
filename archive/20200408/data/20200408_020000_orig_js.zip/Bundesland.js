var dpBundesland = [{"label":"W","y":1820},{"label":"Vbg","y":784},{"label":"T","y":2857},{"label":"Stmk","y":1396},{"label":"Sbg","y":1120},{"label":"OÖ","y":2008},{"label":"NÖ","y":2079},{"label":"Ktn","y":341},{"label":"Bgld","y":235}];
var BundeslandVersion = "08.04.2020 02:00:00 V 1.1.0.0"
