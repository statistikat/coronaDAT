var dpBundesland = [{"label":"W","y":1824},{"label":"Vbg","y":784},{"label":"T","y":2857},{"label":"Stmk","y":1396},{"label":"Sbg","y":1120},{"label":"OÖ","y":2008},{"label":"NÖ","y":2103},{"label":"Ktn","y":341},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 08:00:00 V 1.1.0.0"
