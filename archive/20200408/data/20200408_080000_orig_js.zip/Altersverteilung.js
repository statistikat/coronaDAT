var dpAltersverteilung = [{"label":"<5","y":58},{"label":"5-14","y":286},{"label":"15-24","y":1179},{"label":"25-34","y":1791},{"label":"35-44","y":1809},{"label":"45-54","y":2685},{"label":"55-64","y":2160},{"label":">64","y":2707}];
var AltersverteilungVersion = "08.04.2020 08:00:00 V 1.1.0.0"
