var dpBundesland = [{"label":"W","y":1860},{"label":"Vbg","y":793},{"label":"T","y":2903},{"label":"Stmk","y":1423},{"label":"Sbg","y":1119},{"label":"OÖ","y":2037},{"label":"NÖ","y":2122},{"label":"Ktn","y":353},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 15:00:00 V 1.1.0.0"
