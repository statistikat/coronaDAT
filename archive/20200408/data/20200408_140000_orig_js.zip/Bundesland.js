var dpBundesland = [{"label":"W","y":1844},{"label":"Vbg","y":792},{"label":"T","y":2897},{"label":"Stmk","y":1423},{"label":"Sbg","y":1119},{"label":"OÖ","y":2035},{"label":"NÖ","y":2119},{"label":"Ktn","y":353},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 14:00:00 V 1.1.0.0"
