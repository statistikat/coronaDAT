var dpBundesland = [{"label":"W","y":1827},{"label":"Vbg","y":791},{"label":"T","y":2870},{"label":"Stmk","y":1399},{"label":"Sbg","y":1119},{"label":"OÖ","y":2021},{"label":"NÖ","y":2111},{"label":"Ktn","y":341},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 10:00:00 V 1.1.0.0"
