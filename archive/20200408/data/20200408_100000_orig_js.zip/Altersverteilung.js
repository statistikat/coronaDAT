var dpAltersverteilung = [{"label":"<5","y":58},{"label":"5-14","y":287},{"label":"15-24","y":1182},{"label":"25-34","y":1793},{"label":"35-44","y":1816},{"label":"45-54","y":2700},{"label":"55-64","y":2164},{"label":">64","y":2721}];
var AltersverteilungVersion = "08.04.2020 10:00:00 V 1.1.0.0"
