var dpBundesland = [{"label":"W","y":1826},{"label":"Vbg","y":788},{"label":"T","y":2860},{"label":"Stmk","y":1399},{"label":"Sbg","y":1120},{"label":"OÖ","y":2021},{"label":"NÖ","y":2112},{"label":"Ktn","y":341},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 09:00:00 V 1.1.0.0"
