var dpBundesland = [{"label":"W","y":1865},{"label":"Vbg","y":793},{"label":"T","y":2909},{"label":"Stmk","y":1428},{"label":"Sbg","y":1119},{"label":"OÖ","y":2039},{"label":"NÖ","y":2126},{"label":"Ktn","y":360},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 16:00:00 V 1.1.0.0"
