var Erkrankungen = "12738";
var LetzteAktualisierung = "08.04.2020 12:00.00";
var SimpleDataVersion = "08.04.2020 12:00:00 V 1.1.0.0"
