var dpBundesland = [{"label":"W","y":1827},{"label":"Vbg","y":792},{"label":"T","y":2880},{"label":"Stmk","y":1402},{"label":"Sbg","y":1119},{"label":"OÖ","y":2023},{"label":"NÖ","y":2112},{"label":"Ktn","y":341},{"label":"Bgld","y":242}];
var BundeslandVersion = "08.04.2020 12:00:00 V 1.1.0.0"
