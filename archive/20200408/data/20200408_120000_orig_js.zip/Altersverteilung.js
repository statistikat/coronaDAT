var dpAltersverteilung = [{"label":"<5","y":58},{"label":"5-14","y":288},{"label":"15-24","y":1184},{"label":"25-34","y":1794},{"label":"35-44","y":1819},{"label":"45-54","y":2702},{"label":"55-64","y":2167},{"label":">64","y":2726}];
var AltersverteilungVersion = "08.04.2020 12:00:00 V 1.1.0.0"
