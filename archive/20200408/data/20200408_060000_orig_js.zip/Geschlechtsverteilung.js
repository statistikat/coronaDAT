var dpGeschlechtsverteilung = [{"label":"männlich","y":50},{"label":"weiblich","y":50}];
var GeschlechtsverteilungVersion = "08.04.2020 06:00:00 V 1.1.0.0"
