var dpAltersverteilung = [{"label":"<5","y":57},{"label":"5-14","y":286},{"label":"15-24","y":1174},{"label":"25-34","y":1790},{"label":"35-44","y":1807},{"label":"45-54","y":2679},{"label":"55-64","y":2151},{"label":">64","y":2696}];
var AltersverteilungVersion = "08.04.2020 06:00:00 V 1.1.0.0"
