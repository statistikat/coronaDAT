var dpAltersverteilung = [{"label":"<5","y":67},{"label":"5-14","y":296},{"label":"15-24","y":1231},{"label":"25-34","y":1863},{"label":"35-44","y":1878},{"label":"45-54","y":2813},{"label":"55-64","y":2232},{"label":">64","y":2839}];
var AltersverteilungVersion = "09.04.2020 18:00:00 V 1.1.0.0"
