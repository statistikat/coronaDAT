var Erkrankungen = "12969";
var LetzteAktualisierung = "09.04.2020 08:00.00";
var SimpleDataVersion = "09.04.2020 08:00:00 V 1.1.0.0"
