var dpAltersverteilung = [{"label":"<5","y":59},{"label":"5-14","y":294},{"label":"15-24","y":1204},{"label":"25-34","y":1834},{"label":"35-44","y":1847},{"label":"45-54","y":2761},{"label":"55-64","y":2194},{"label":">64","y":2776}];
var AltersverteilungVersion = "09.04.2020 08:00:00 V 1.1.0.0"
