var dpBundesland = [{"label":"W","y":1878},{"label":"Vbg","y":794},{"label":"T","y":2931},{"label":"Stmk","y":1434},{"label":"Sbg","y":1129},{"label":"OÖ","y":2048},{"label":"NÖ","y":2151},{"label":"Ktn","y":361},{"label":"Bgld","y":243}];
var BundeslandVersion = "09.04.2020 08:00:00 V 1.1.0.0"
