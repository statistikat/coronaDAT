var dpBundesland = [{"label":"W","y":1915},{"label":"Vbg","y":797},{"label":"T","y":3027},{"label":"Stmk","y":1463},{"label":"Sbg","y":1140},{"label":"OÖ","y":2080},{"label":"NÖ","y":2172},{"label":"Ktn","y":366},{"label":"Bgld","y":246}];
var BundeslandVersion = "09.04.2020 17:00:00 V 1.1.0.0"
