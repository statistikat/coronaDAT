var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":296},{"label":"15-24","y":1229},{"label":"25-34","y":1860},{"label":"35-44","y":1876},{"label":"45-54","y":2810},{"label":"55-64","y":2231},{"label":">64","y":2838}];
var AltersverteilungVersion = "09.04.2020 17:00:00 V 1.1.0.0"
