var dpBundesland = [{"label":"W","y":1892},{"label":"Vbg","y":800},{"label":"T","y":2996},{"label":"Stmk","y":1458},{"label":"Sbg","y":1134},{"label":"OÖ","y":2079},{"label":"NÖ","y":2169},{"label":"Ktn","y":365},{"label":"Bgld","y":245}];
var BundeslandVersion = "09.04.2020 15:00:00 V 1.1.0.0"
