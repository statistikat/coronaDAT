var dpBundesland = [{"label":"W","y":1918},{"label":"Vbg","y":801},{"label":"T","y":3045},{"label":"Stmk","y":1468},{"label":"Sbg","y":1143},{"label":"OÖ","y":2085},{"label":"NÖ","y":2176},{"label":"Ktn","y":366},{"label":"Bgld","y":246}];
var BundeslandVersion = "09.04.2020 23:00:00 V 1.1.0.0"
