var dpAltersverteilung = [{"label":"<5","y":59},{"label":"5-14","y":294},{"label":"15-24","y":1206},{"label":"25-34","y":1835},{"label":"35-44","y":1848},{"label":"45-54","y":2762},{"label":"55-64","y":2196},{"label":">64","y":2781}];
var AltersverteilungVersion = "09.04.2020 09:00:00 V 1.1.0.0"
