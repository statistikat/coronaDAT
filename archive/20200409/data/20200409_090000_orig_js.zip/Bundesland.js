var dpBundesland = [{"label":"W","y":1879},{"label":"Vbg","y":794},{"label":"T","y":2931},{"label":"Stmk","y":1435},{"label":"Sbg","y":1129},{"label":"OÖ","y":2055},{"label":"NÖ","y":2154},{"label":"Ktn","y":361},{"label":"Bgld","y":243}];
var BundeslandVersion = "09.04.2020 09:00:00 V 1.1.0.0"
