var dpAltersverteilung = [{"label":"<5","y":64},{"label":"5-14","y":294},{"label":"15-24","y":1216},{"label":"25-34","y":1850},{"label":"35-44","y":1862},{"label":"45-54","y":2787},{"label":"55-64","y":2215},{"label":">64","y":2817}];
var AltersverteilungVersion = "09.04.2020 14:00:00 V 1.1.0.0"
