var dpBundesland = [{"label":"W","y":1891},{"label":"Vbg","y":800},{"label":"T","y":2977},{"label":"Stmk","y":1457},{"label":"Sbg","y":1130},{"label":"OÖ","y":2079},{"label":"NÖ","y":2165},{"label":"Ktn","y":361},{"label":"Bgld","y":245}];
var BundeslandVersion = "09.04.2020 14:00:00 V 1.1.0.0"
