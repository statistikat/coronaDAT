var dpBundesland = [{"label":"W","y":1878},{"label":"Vbg","y":794},{"label":"T","y":2929},{"label":"Stmk","y":1432},{"label":"Sbg","y":1129},{"label":"OÖ","y":2048},{"label":"NÖ","y":2128},{"label":"Ktn","y":360},{"label":"Bgld","y":244}];
var BundeslandVersion = "09.04.2020 03:00:00 V 1.1.0.0"
