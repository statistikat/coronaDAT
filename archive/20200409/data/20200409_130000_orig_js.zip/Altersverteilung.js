var dpAltersverteilung = [{"label":"<5","y":63},{"label":"5-14","y":294},{"label":"15-24","y":1211},{"label":"25-34","y":1846},{"label":"35-44","y":1859},{"label":"45-54","y":2785},{"label":"55-64","y":2212},{"label":">64","y":2804}];
var AltersverteilungVersion = "09.04.2020 13:00:00 V 1.1.0.0"
