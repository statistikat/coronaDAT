var dpBundesland = [{"label":"W","y":1885},{"label":"Vbg","y":800},{"label":"T","y":2967},{"label":"Stmk","y":1452},{"label":"Sbg","y":1130},{"label":"OÖ","y":2073},{"label":"NÖ","y":2161},{"label":"Ktn","y":362},{"label":"Bgld","y":244}];
var BundeslandVersion = "09.04.2020 13:00:00 V 1.1.0.0"
