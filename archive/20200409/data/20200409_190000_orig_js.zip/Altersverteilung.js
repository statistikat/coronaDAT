var dpAltersverteilung = [{"label":"<5","y":67},{"label":"5-14","y":297},{"label":"15-24","y":1233},{"label":"25-34","y":1866},{"label":"35-44","y":1878},{"label":"45-54","y":2814},{"label":"55-64","y":2235},{"label":">64","y":2843}];
var AltersverteilungVersion = "09.04.2020 19:00:00 V 1.1.0.0"
