var dpBundesland = [{"label":"W","y":1917},{"label":"Vbg","y":798},{"label":"T","y":3043},{"label":"Stmk","y":1467},{"label":"Sbg","y":1140},{"label":"OÖ","y":2082},{"label":"NÖ","y":2174},{"label":"Ktn","y":366},{"label":"Bgld","y":246}];
var BundeslandVersion = "09.04.2020 19:00:00 V 1.1.0.0"
