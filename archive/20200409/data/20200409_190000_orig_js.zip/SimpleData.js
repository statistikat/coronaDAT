var Erkrankungen = "13233";
var LetzteAktualisierung = "09.04.2020 19:00.00";
var SimpleDataVersion = "09.04.2020 19:00:00 V 1.1.0.0"
