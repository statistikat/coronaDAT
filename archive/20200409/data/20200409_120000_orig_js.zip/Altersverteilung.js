var dpAltersverteilung = [{"label":"<5","y":61},{"label":"5-14","y":294},{"label":"15-24","y":1210},{"label":"25-34","y":1842},{"label":"35-44","y":1854},{"label":"45-54","y":2769},{"label":"55-64","y":2205},{"label":">64","y":2793}];
var AltersverteilungVersion = "09.04.2020 12:00:00 V 1.1.0.0"
