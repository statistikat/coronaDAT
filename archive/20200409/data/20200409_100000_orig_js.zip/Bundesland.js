var dpBundesland = [{"label":"W","y":1882},{"label":"Vbg","y":797},{"label":"T","y":2946},{"label":"Stmk","y":1435},{"label":"Sbg","y":1129},{"label":"OÖ","y":2055},{"label":"NÖ","y":2157},{"label":"Ktn","y":361},{"label":"Bgld","y":243}];
var BundeslandVersion = "09.04.2020 10:00:00 V 1.1.0.0"
