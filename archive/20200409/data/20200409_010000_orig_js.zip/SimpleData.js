var Erkrankungen = "12942";
var LetzteAktualisierung = "09.04.2020 01:00.00";
var SimpleDataVersion = "09.04.2020 01:00:00 V 1.1.0.0"
