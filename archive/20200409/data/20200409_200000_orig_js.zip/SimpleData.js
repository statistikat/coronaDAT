var Erkrankungen = "13237";
var LetzteAktualisierung = "09.04.2020 20:00.00";
var SimpleDataVersion = "09.04.2020 20:00:00 V 1.1.0.0"
