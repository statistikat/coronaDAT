var dpAltersverteilung = [{"label":"<5","y":67},{"label":"5-14","y":297},{"label":"15-24","y":1234},{"label":"25-34","y":1867},{"label":"35-44","y":1878},{"label":"45-54","y":2814},{"label":"55-64","y":2236},{"label":">64","y":2844}];
var AltersverteilungVersion = "09.04.2020 20:00:00 V 1.1.0.0"
