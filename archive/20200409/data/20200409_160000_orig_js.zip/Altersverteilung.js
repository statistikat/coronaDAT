var dpAltersverteilung = [{"label":"<5","y":66},{"label":"5-14","y":297},{"label":"15-24","y":1223},{"label":"25-34","y":1855},{"label":"35-44","y":1870},{"label":"45-54","y":2802},{"label":"55-64","y":2220},{"label":">64","y":2830}];
var AltersverteilungVersion = "09.04.2020 16:00:00 V 1.1.0.0"
