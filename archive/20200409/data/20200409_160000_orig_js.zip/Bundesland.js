var dpBundesland = [{"label":"W","y":1911},{"label":"Vbg","y":800},{"label":"T","y":2996},{"label":"Stmk","y":1459},{"label":"Sbg","y":1134},{"label":"OÖ","y":2081},{"label":"NÖ","y":2171},{"label":"Ktn","y":366},{"label":"Bgld","y":245}];
var BundeslandVersion = "09.04.2020 16:00:00 V 1.1.0.0"
