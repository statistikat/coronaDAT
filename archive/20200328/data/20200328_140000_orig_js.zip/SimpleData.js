var Erkrankungen = 7995;
var LetzteAktualisierung = "28.03.2020 14:00.00";
