var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 05:00.00";
