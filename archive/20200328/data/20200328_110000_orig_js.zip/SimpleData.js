var Erkrankungen = 7823;
var LetzteAktualisierung = "28.03.2020 11:00.00";
