var Erkrankungen = 7898;
var LetzteAktualisierung = "28.03.2020 12:00.00";
