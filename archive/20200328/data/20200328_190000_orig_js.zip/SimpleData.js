var Erkrankungen = 8188;
var LetzteAktualisierung = "28.03.2020 19:00.00";
