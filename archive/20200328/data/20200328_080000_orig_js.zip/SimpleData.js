var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 08:00.00";
