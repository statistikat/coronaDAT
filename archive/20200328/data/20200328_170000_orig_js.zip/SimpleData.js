var Erkrankungen = 8105;
var LetzteAktualisierung = "28.03.2020 17:00.00";
