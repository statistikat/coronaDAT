var Erkrankungen = 7750;
var LetzteAktualisierung = "28.03.2020 10:00.00";
