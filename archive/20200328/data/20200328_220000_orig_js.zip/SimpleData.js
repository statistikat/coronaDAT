var Erkrankungen = 8259;
var LetzteAktualisierung = "28.03.2020 22:00.00";
