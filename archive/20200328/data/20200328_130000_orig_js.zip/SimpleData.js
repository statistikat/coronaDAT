var Erkrankungen = 7964;
var LetzteAktualisierung = "28.03.2020 13:00.00";
