var Erkrankungen = 8068;
var LetzteAktualisierung = "28.03.2020 16:00.00";
