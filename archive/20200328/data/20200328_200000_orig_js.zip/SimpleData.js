var Erkrankungen = 8233;
var LetzteAktualisierung = "28.03.2020 20:00.00";
