var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 07:00.00";
