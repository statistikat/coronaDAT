var Erkrankungen = 8258;
var LetzteAktualisierung = "28.03.2020 21:00.00";
