var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 04:00.00";
