var Erkrankungen = 7712;
var LetzteAktualisierung = "28.03.2020 09:00.00";
