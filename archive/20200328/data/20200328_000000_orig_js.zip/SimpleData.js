var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 00:00.00";
