var Erkrankungen = 8030;
var LetzteAktualisierung = "28.03.2020 15:00.00";
