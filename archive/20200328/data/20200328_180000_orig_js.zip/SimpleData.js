var Erkrankungen = 8122;
var LetzteAktualisierung = "28.03.2020 18:00.00";
