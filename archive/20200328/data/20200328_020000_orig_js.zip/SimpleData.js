var Erkrankungen = 7697;
var LetzteAktualisierung = "28.03.2020 02:00.00";
