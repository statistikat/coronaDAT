var Erkrankungen = 8271;
var LetzteAktualisierung = "28.03.2020 23:00.00";
