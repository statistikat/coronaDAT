var Erkrankungen = "13972";
var LetzteAktualisierung = "13.04.2020 11:00.00";
var SimpleDataVersion = "13.04.2020 11:00:00 V 1.1.0.0"
