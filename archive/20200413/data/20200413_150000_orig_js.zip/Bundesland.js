var dpBundesland = [{"label":"W","y":2015},{"label":"Vbg","y":832},{"label":"T","y":3299},{"label":"Stmk","y":1560},{"label":"Sbg","y":1169},{"label":"OÖ","y":2127},{"label":"NÖ","y":2343},{"label":"Ktn","y":386},{"label":"Bgld","y":268}];
var BundeslandVersion = "13.04.2020 15:00:00 V 1.1.0.0"
