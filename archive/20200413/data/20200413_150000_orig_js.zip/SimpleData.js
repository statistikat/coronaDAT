var Erkrankungen = "13999";
var LetzteAktualisierung = "13.04.2020 15:00.00";
var SimpleDataVersion = "13.04.2020 15:00:00 V 1.1.0.0"
