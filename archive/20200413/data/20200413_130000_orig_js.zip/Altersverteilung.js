var dpAltersverteilung = [{"label":"<5","y":71},{"label":"5-14","y":315},{"label":"15-24","y":1315},{"label":"25-34","y":1948},{"label":"35-44","y":1962},{"label":"45-54","y":2962},{"label":"55-64","y":2367},{"label":">64","y":3044}];
var AltersverteilungVersion = "13.04.2020 13:00:00 V 1.1.0.0"
