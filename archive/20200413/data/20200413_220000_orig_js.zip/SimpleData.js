var Erkrankungen = "14043";
var LetzteAktualisierung = "13.04.2020 22:00.00";
var SimpleDataVersion = "13.04.2020 22:00:00 V 1.1.0.0"
