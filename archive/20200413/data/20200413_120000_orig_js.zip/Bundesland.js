var dpBundesland = [{"label":"W","y":2011},{"label":"Vbg","y":831},{"label":"T","y":3293},{"label":"Stmk","y":1553},{"label":"Sbg","y":1169},{"label":"OÖ","y":2122},{"label":"NÖ","y":2343},{"label":"Ktn","y":386},{"label":"Bgld","y":266}];
var BundeslandVersion = "13.04.2020 12:00:00 V 1.1.0.0"
