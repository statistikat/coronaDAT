var Erkrankungen = "13937";
var LetzteAktualisierung = "13.04.2020 02:00.00";
var SimpleDataVersion = "13.04.2020 02:00:00 V 1.1.0.0"
