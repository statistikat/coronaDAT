var dpBundesland = [{"label":"W","y":2016},{"label":"Vbg","y":832},{"label":"T","y":3299},{"label":"Stmk","y":1566},{"label":"Sbg","y":1171},{"label":"OÖ","y":2131},{"label":"NÖ","y":2344},{"label":"Ktn","y":386},{"label":"Bgld","y":268}];
var BundeslandVersion = "13.04.2020 16:00:00 V 1.1.0.0"
