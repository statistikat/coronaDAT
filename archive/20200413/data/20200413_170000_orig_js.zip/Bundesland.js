var dpBundesland = [{"label":"W","y":2018},{"label":"Vbg","y":832},{"label":"T","y":3299},{"label":"Stmk","y":1567},{"label":"Sbg","y":1172},{"label":"OÖ","y":2132},{"label":"NÖ","y":2344},{"label":"Ktn","y":386},{"label":"Bgld","y":268}];
var BundeslandVersion = "13.04.2020 17:00:00 V 1.1.0.0"
