var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":315},{"label":"15-24","y":1309},{"label":"25-34","y":1944},{"label":"35-44","y":1957},{"label":"45-54","y":2956},{"label":"55-64","y":2355},{"label":">64","y":3037}];
var AltersverteilungVersion = "13.04.2020 08:00:00 V 1.1.0.0"
