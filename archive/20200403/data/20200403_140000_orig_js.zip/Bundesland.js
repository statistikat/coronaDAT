var dpBundesland = [{"label":"W","y":1645},{"label":"Vbg","y":708},{"label":"T","y":2591},{"label":"Stmk","y":1204},{"label":"Sbg","y":1033},{"label":"OÖ","y":1831},{"label":"NÖ","y":1828},{"label":"Ktn","y":304},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 14:00:00 V 1.1.0.0"
