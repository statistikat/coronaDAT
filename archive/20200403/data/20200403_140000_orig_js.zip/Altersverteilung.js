var dpAltersverteilung = [{"label":"<5","y":50},{"label":"5-14","y":258},{"label":"15-24","y":1056},{"label":"25-34","y":1624},{"label":"35-44","y":1654},{"label":"45-54","y":2417},{"label":"55-64","y":1955},{"label":">64","y":2336}];
var AltersverteilungVersion = "03.04.2020 14:00:00 V 1.1.0.0"
