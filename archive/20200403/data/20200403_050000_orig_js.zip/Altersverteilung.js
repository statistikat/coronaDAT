var dpAltersverteilung = [{"label":"<5","y":47},{"label":"5-14","y":253},{"label":"15-24","y":1035},{"label":"25-34","y":1594},{"label":"35-44","y":1627},{"label":"45-54","y":2371},{"label":"55-64","y":1918},{"label":">64","y":2284}];
var AltersverteilungVersion = "03.04.2020 05:00:00 V 1.1.0.0"
