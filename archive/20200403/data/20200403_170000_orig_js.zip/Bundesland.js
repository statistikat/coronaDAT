var dpBundesland = [{"label":"W","y":1668},{"label":"Vbg","y":713},{"label":"T","y":2608},{"label":"Stmk","y":1212},{"label":"Sbg","y":1045},{"label":"OÖ","y":1855},{"label":"NÖ","y":1830},{"label":"Ktn","y":307},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 17:00:00 V 1.1.0.0"
