var dpAltersverteilung = [{"label":"<5","y":52},{"label":"5-14","y":260},{"label":"15-24","y":1068},{"label":"25-34","y":1651},{"label":"35-44","y":1674},{"label":"45-54","y":2455},{"label":"55-64","y":1973},{"label":">64","y":2373}];
var AltersverteilungVersion = "03.04.2020 20:00:00 V 1.1.0.0"
