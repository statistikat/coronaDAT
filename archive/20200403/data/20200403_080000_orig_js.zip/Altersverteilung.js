var dpAltersverteilung = [{"label":"<5","y":47},{"label":"5-14","y":253},{"label":"15-24","y":1037},{"label":"25-34","y":1599},{"label":"35-44","y":1635},{"label":"45-54","y":2377},{"label":"55-64","y":1924},{"label":">64","y":2299}];
var AltersverteilungVersion = "03.04.2020 08:00:00 V 1.1.0.0"
