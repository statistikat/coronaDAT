var dpBundesland = [{"label":"W","y":1620},{"label":"Vbg","y":697},{"label":"T","y":2568},{"label":"Stmk","y":1169},{"label":"Sbg","y":1033},{"label":"OÖ","y":1806},{"label":"NÖ","y":1775},{"label":"Ktn","y":300},{"label":"Bgld","y":203}];
var BundeslandVersion = "03.04.2020 08:00:00 V 1.1.0.0"
