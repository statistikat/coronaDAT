var Erkrankungen = "11251";
var LetzteAktualisierung = "03.04.2020 12:00.00";
var SimpleDataVersion = "03.04.2020 12:00:00 V 1.1.0.0"
