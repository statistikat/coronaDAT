var dpBundesland = [{"label":"W","y":1626},{"label":"Vbg","y":697},{"label":"T","y":2587},{"label":"Stmk","y":1179},{"label":"Sbg","y":1033},{"label":"OÖ","y":1816},{"label":"NÖ","y":1806},{"label":"Ktn","y":301},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 12:00:00 V 1.1.0.0"
