var dpAltersverteilung = [{"label":"<5","y":52},{"label":"5-14","y":260},{"label":"15-24","y":1067},{"label":"25-34","y":1648},{"label":"35-44","y":1671},{"label":"45-54","y":2453},{"label":"55-64","y":1971},{"label":">64","y":2367}];
var AltersverteilungVersion = "03.04.2020 19:00:00 V 1.1.0.0"
