var dpBundesland = [{"label":"W","y":1677},{"label":"Vbg","y":713},{"label":"T","y":2627},{"label":"Stmk","y":1219},{"label":"Sbg","y":1049},{"label":"OÖ","y":1859},{"label":"NÖ","y":1831},{"label":"Ktn","y":307},{"label":"Bgld","y":207}];
var BundeslandVersion = "03.04.2020 19:00:00 V 1.1.0.0"
