var dpBundesland = [{"label":"W","y":1675},{"label":"Vbg","y":713},{"label":"T","y":2621},{"label":"Stmk","y":1210},{"label":"Sbg","y":1046},{"label":"OÖ","y":1855},{"label":"NÖ","y":1831},{"label":"Ktn","y":307},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 18:00:00 V 1.1.0.0"
