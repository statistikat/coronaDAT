var dpBundesland = [{"label":"W","y":1635},{"label":"Vbg","y":708},{"label":"T","y":2589},{"label":"Stmk","y":1193},{"label":"Sbg","y":1033},{"label":"OÖ","y":1827},{"label":"NÖ","y":1808},{"label":"Ktn","y":302},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 13:00:00 V 1.1.0.0"
