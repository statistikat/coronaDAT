var dpAltersverteilung = [{"label":"<5","y":50},{"label":"5-14","y":258},{"label":"15-24","y":1061},{"label":"25-34","y":1636},{"label":"35-44","y":1662},{"label":"45-54","y":2434},{"label":"55-64","y":1963},{"label":">64","y":2348}];
var AltersverteilungVersion = "03.04.2020 16:00:00 V 1.1.0.0"
