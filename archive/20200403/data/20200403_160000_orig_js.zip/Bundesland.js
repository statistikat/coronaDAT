var dpBundesland = [{"label":"W","y":1666},{"label":"Vbg","y":710},{"label":"T","y":2601},{"label":"Stmk","y":1212},{"label":"Sbg","y":1039},{"label":"OÖ","y":1843},{"label":"NÖ","y":1828},{"label":"Ktn","y":307},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 16:00:00 V 1.1.0.0"
