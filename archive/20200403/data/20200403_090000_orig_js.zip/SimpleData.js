var Erkrankungen = "11199";
var LetzteAktualisierung = "03.04.2020 09:00.00";
var SimpleDataVersion = "03.04.2020 09:00:00 V 1.1.0.0"
