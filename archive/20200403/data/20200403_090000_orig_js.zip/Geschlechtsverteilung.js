var dpGeschlechtsverteilung = [{"label":"männlich","y":51},{"label":"weiblich","y":49}];
var GeschlechtsverteilungVersion = "03.04.2020 09:00:00 V 1.1.0.0"
