var dpBundesland = [{"label":"W","y":1621},{"label":"Vbg","y":697},{"label":"T","y":2575},{"label":"Stmk","y":1169},{"label":"Sbg","y":1033},{"label":"OÖ","y":1810},{"label":"NÖ","y":1790},{"label":"Ktn","y":300},{"label":"Bgld","y":204}];
var BundeslandVersion = "03.04.2020 09:00:00 V 1.1.0.0"
