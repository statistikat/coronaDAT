var dpBundesland = [{"label":"W","y":1607},{"label":"Vbg","y":697},{"label":"T","y":2569},{"label":"Stmk","y":1169},{"label":"Sbg","y":1033},{"label":"OÖ","y":1805},{"label":"NÖ","y":1746},{"label":"Ktn","y":300},{"label":"Bgld","y":203}];
var BundeslandVersion = "03.04.2020 01:00:00 V 1.1.0.0"
