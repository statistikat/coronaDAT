var dpAltersverteilung = [{"label":"<5","y":50},{"label":"5-14","y":258},{"label":"15-24","y":1058},{"label":"25-34","y":1630},{"label":"35-44","y":1659},{"label":"45-54","y":2428},{"label":"55-64","y":1959},{"label":">64","y":2341}];
var AltersverteilungVersion = "03.04.2020 15:00:00 V 1.1.0.0"
