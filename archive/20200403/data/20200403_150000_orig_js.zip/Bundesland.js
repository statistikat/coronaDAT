var dpBundesland = [{"label":"W","y":1661},{"label":"Vbg","y":710},{"label":"T","y":2595},{"label":"Stmk","y":1205},{"label":"Sbg","y":1038},{"label":"OÖ","y":1836},{"label":"NÖ","y":1828},{"label":"Ktn","y":304},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 15:00:00 V 1.1.0.0"
