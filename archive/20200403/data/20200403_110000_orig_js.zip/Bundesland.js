var dpBundesland = [{"label":"W","y":1625},{"label":"Vbg","y":697},{"label":"T","y":2580},{"label":"Stmk","y":1179},{"label":"Sbg","y":1033},{"label":"OÖ","y":1810},{"label":"NÖ","y":1807},{"label":"Ktn","y":301},{"label":"Bgld","y":206}];
var BundeslandVersion = "03.04.2020 11:00:00 V 1.1.0.0"
