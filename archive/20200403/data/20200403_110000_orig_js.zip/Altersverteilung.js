var dpAltersverteilung = [{"label":"<5","y":48},{"label":"5-14","y":254},{"label":"15-24","y":1043},{"label":"25-34","y":1607},{"label":"35-44","y":1645},{"label":"45-54","y":2396},{"label":"55-64","y":1939},{"label":">64","y":2306}];
var AltersverteilungVersion = "03.04.2020 11:00:00 V 1.1.0.0"
