var dpBundesland = [{"label":"W","y":1996},{"label":"Vbg","y":826},{"label":"T","y":3272},{"label":"Stmk","y":1526},{"label":"Sbg","y":1157},{"label":"OÖ","y":2120},{"label":"NÖ","y":2324},{"label":"Ktn","y":384},{"label":"Bgld","y":260}];
var BundeslandVersion = "12.04.2020 12:00:00 V 1.1.0.0"
