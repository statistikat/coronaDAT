var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":313},{"label":"15-24","y":1302},{"label":"25-34","y":1937},{"label":"35-44","y":1953},{"label":"45-54","y":2938},{"label":"55-64","y":2344},{"label":">64","y":3009}];
var AltersverteilungVersion = "12.04.2020 12:00:00 V 1.1.0.0"
