var Erkrankungen = "13865";
var LetzteAktualisierung = "12.04.2020 12:00.00";
var SimpleDataVersion = "12.04.2020 12:00:00 V 1.1.0.0"
