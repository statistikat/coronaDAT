var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":312},{"label":"15-24","y":1299},{"label":"25-34","y":1934},{"label":"35-44","y":1949},{"label":"45-54","y":2930},{"label":"55-64","y":2338},{"label":">64","y":3007}];
var AltersverteilungVersion = "12.04.2020 11:00:00 V 1.1.0.0"
