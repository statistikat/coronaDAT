var dpBundesland = [{"label":"W","y":1997},{"label":"Vbg","y":826},{"label":"T","y":3264},{"label":"Stmk","y":1524},{"label":"Sbg","y":1157},{"label":"OÖ","y":2119},{"label":"NÖ","y":2289},{"label":"Ktn","y":383},{"label":"Bgld","y":259}];
var BundeslandVersion = "12.04.2020 10:00:00 V 1.1.0.0"
