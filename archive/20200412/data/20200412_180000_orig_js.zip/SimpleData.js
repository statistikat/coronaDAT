var Erkrankungen = "13926";
var LetzteAktualisierung = "12.04.2020 18:00.00";
var SimpleDataVersion = "12.04.2020 18:00:00 V 1.1.0.0"
