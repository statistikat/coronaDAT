var dpBundesland = [{"label":"W","y":2003},{"label":"Vbg","y":831},{"label":"T","y":3278},{"label":"Stmk","y":1553},{"label":"Sbg","y":1169},{"label":"OÖ","y":2122},{"label":"NÖ","y":2324},{"label":"Ktn","y":385},{"label":"Bgld","y":261}];
var BundeslandVersion = "12.04.2020 18:00:00 V 1.1.0.0"
