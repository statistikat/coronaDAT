var dpBundesland = [{"label":"W","y":2008},{"label":"Vbg","y":831},{"label":"T","y":3279},{"label":"Stmk","y":1553},{"label":"Sbg","y":1169},{"label":"OÖ","y":2122},{"label":"NÖ","y":2324},{"label":"Ktn","y":385},{"label":"Bgld","y":266}];
var BundeslandVersion = "12.04.2020 23:00:00 V 1.1.0.0"
