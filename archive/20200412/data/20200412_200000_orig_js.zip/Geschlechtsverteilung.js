var dpGeschlechtsverteilung = [{"label":"männlich","y":50},{"label":"weiblich","y":50}];
var GeschlechtsverteilungVersion = "12.04.2020 20:00:00 V 1.1.0.0"
