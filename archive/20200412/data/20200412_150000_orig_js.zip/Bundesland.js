var dpBundesland = [{"label":"W","y":2000},{"label":"Vbg","y":830},{"label":"T","y":3278},{"label":"Stmk","y":1538},{"label":"Sbg","y":1159},{"label":"OÖ","y":2120},{"label":"NÖ","y":2325},{"label":"Ktn","y":384},{"label":"Bgld","y":260}];
var BundeslandVersion = "12.04.2020 15:00:00 V 1.1.0.0"
