var dpBundesland = [{"label":"W","y":1997},{"label":"Vbg","y":829},{"label":"T","y":3277},{"label":"Stmk","y":1530},{"label":"Sbg","y":1157},{"label":"OÖ","y":2119},{"label":"NÖ","y":2324},{"label":"Ktn","y":384},{"label":"Bgld","y":260}];
var BundeslandVersion = "12.04.2020 13:00:00 V 1.1.0.0"
