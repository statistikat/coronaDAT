var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":314},{"label":"15-24","y":1303},{"label":"25-34","y":1940},{"label":"35-44","y":1953},{"label":"45-54","y":2938},{"label":"55-64","y":2346},{"label":">64","y":3014}];
var AltersverteilungVersion = "12.04.2020 13:00:00 V 1.1.0.0"
