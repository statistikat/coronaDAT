var dpBundesland = [{"label":"W","y":2001},{"label":"Vbg","y":831},{"label":"T","y":3278},{"label":"Stmk","y":1549},{"label":"Sbg","y":1168},{"label":"OÖ","y":2122},{"label":"NÖ","y":2325},{"label":"Ktn","y":384},{"label":"Bgld","y":260}];
var BundeslandVersion = "12.04.2020 17:00:00 V 1.1.0.0"
