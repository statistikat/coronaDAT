var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":311},{"label":"15-24","y":1297},{"label":"25-34","y":1931},{"label":"35-44","y":1945},{"label":"45-54","y":2924},{"label":"55-64","y":2331},{"label":">64","y":2998}];
var AltersverteilungVersion = "12.04.2020 01:00:00 V 1.1.0.0"
