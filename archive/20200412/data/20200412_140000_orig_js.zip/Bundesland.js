var dpBundesland = [{"label":"W","y":2000},{"label":"Vbg","y":830},{"label":"T","y":3277},{"label":"Stmk","y":1537},{"label":"Sbg","y":1157},{"label":"OÖ","y":2120},{"label":"NÖ","y":2325},{"label":"Ktn","y":384},{"label":"Bgld","y":260}];
var BundeslandVersion = "12.04.2020 14:00:00 V 1.1.0.0"
