var dpAltersverteilung = [{"label":"<5","y":69},{"label":"5-14","y":314},{"label":"15-24","y":1305},{"label":"25-34","y":1941},{"label":"35-44","y":1954},{"label":"45-54","y":2939},{"label":"55-64","y":2346},{"label":">64","y":3022}];
var AltersverteilungVersion = "12.04.2020 14:00:00 V 1.1.0.0"
