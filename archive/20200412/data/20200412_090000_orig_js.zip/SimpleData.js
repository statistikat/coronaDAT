var Erkrankungen = "13814";
var LetzteAktualisierung = "12.04.2020 09:00.00";
var SimpleDataVersion = "12.04.2020 09:00:00 V 1.1.0.0"
