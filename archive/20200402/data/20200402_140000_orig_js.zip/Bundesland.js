var dpBundesland = [{"label":"W","y":1567},{"label":"Vbg","y":681},{"label":"T","y":2528},{"label":"Stmk","y":1146},{"label":"Sbg","y":994},{"label":"OÖ","y":1774},{"label":"NÖ","y":1735},{"label":"Ktn","y":301},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 14:00:00 V 1.1.0.0"
