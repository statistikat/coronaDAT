var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":252},{"label":"15-24","y":1036},{"label":"25-34","y":1592},{"label":"35-44","y":1623},{"label":"45-54","y":2366},{"label":"55-64","y":1913},{"label":">64","y":2280}];
var AltersverteilungVersion = "02.04.2020 21:00:00 V 1.1.0.0"
