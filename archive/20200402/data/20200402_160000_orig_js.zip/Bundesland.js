var dpBundesland = [{"label":"W","y":1593},{"label":"Vbg","y":685},{"label":"T","y":2537},{"label":"Stmk","y":1161},{"label":"Sbg","y":995},{"label":"OÖ","y":1786},{"label":"NÖ","y":1738},{"label":"Ktn","y":300},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 16:00:00 V 1.1.0.0"
