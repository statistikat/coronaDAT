var Erkrankungen = "10996";
var LetzteAktualisierung = "02.04.2020 16:00.00";
var SimpleDataVersion = "02.04.2020 16:00:00 V 1.1.0.0"
