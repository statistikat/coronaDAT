var dpBundesland = [{"label":"W","y":1560},{"label":"Vbg","y":680},{"label":"T","y":2519},{"label":"Stmk","y":1135},{"label":"Sbg","y":993},{"label":"OÖ","y":1759},{"label":"NÖ","y":1733},{"label":"Ktn","y":297},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 12:00:00 V 1.1.0.0"
