var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":243},{"label":"15-24","y":1012},{"label":"25-34","y":1560},{"label":"35-44","y":1590},{"label":"45-54","y":2314},{"label":"55-64","y":1881},{"label":">64","y":2231}];
var AltersverteilungVersion = "02.04.2020 12:00:00 V 1.1.0.0"
