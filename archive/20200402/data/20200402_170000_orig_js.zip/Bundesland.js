var dpBundesland = [{"label":"W","y":1603},{"label":"Vbg","y":694},{"label":"T","y":2540},{"label":"Stmk","y":1162},{"label":"Sbg","y":997},{"label":"OÖ","y":1790},{"label":"NÖ","y":1740},{"label":"Ktn","y":300},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 17:00:00 V 1.1.0.0"
