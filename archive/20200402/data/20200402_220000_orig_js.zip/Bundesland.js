var dpBundesland = [{"label":"W","y":1607},{"label":"Vbg","y":695},{"label":"T","y":2569},{"label":"Stmk","y":1169},{"label":"Sbg","y":1031},{"label":"OÖ","y":1804},{"label":"NÖ","y":1745},{"label":"Ktn","y":300},{"label":"Bgld","y":203}];
var BundeslandVersion = "02.04.2020 22:00:00 V 1.1.0.0"
