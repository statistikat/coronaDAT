var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":252},{"label":"15-24","y":1035},{"label":"25-34","y":1585},{"label":"35-44","y":1617},{"label":"45-54","y":2353},{"label":"55-64","y":1908},{"label":">64","y":2267}];
var AltersverteilungVersion = "02.04.2020 18:00:00 V 1.1.0.0"
