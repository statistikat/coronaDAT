var dpBundesland = [{"label":"W","y":1606},{"label":"Vbg","y":694},{"label":"T","y":2562},{"label":"Stmk","y":1166},{"label":"Sbg","y":997},{"label":"OÖ","y":1796},{"label":"NÖ","y":1740},{"label":"Ktn","y":300},{"label":"Bgld","y":202}];
var BundeslandVersion = "02.04.2020 18:00:00 V 1.1.0.0"
