var dpBundesland = [{"label":"W","y":1554},{"label":"Vbg","y":680},{"label":"T","y":2514},{"label":"Stmk","y":1135},{"label":"Sbg","y":993},{"label":"OÖ","y":1754},{"label":"NÖ","y":1733},{"label":"Ktn","y":297},{"label":"Bgld","y":199}];
var BundeslandVersion = "02.04.2020 11:00:00 V 1.1.0.0"
