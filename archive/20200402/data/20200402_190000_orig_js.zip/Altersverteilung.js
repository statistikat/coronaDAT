var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":252},{"label":"15-24","y":1033},{"label":"25-34","y":1589},{"label":"35-44","y":1619},{"label":"45-54","y":2356},{"label":"55-64","y":1909},{"label":">64","y":2272}];
var AltersverteilungVersion = "02.04.2020 19:00:00 V 1.1.0.0"
