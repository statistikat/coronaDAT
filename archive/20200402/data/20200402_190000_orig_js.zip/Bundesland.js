var dpBundesland = [{"label":"W","y":1607},{"label":"Vbg","y":693},{"label":"T","y":2567},{"label":"Stmk","y":1169},{"label":"Sbg","y":997},{"label":"OÖ","y":1799},{"label":"NÖ","y":1741},{"label":"Ktn","y":300},{"label":"Bgld","y":203}];
var BundeslandVersion = "02.04.2020 19:00:00 V 1.1.0.0"
