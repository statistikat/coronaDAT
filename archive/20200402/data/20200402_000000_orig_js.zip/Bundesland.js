var dpBundesland = [{"label":"W","y":1547},{"label":"Vbg","y":674},{"label":"T","y":2453},{"label":"Stmk","y":1125},{"label":"Sbg","y":993},{"label":"OÖ","y":1739},{"label":"NÖ","y":1689},{"label":"Ktn","y":293},{"label":"Bgld","y":198}];
var BundeslandVersion = "02.04.2020 00:00:00 V 1.1.0.0"
