var dpBundesland = [{"label":"W","y":1560},{"label":"Vbg","y":681},{"label":"T","y":2520},{"label":"Stmk","y":1146},{"label":"Sbg","y":994},{"label":"OÖ","y":1760},{"label":"NÖ","y":1733},{"label":"Ktn","y":297},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 13:00:00 V 1.1.0.0"
