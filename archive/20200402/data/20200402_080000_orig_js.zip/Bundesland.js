var dpBundesland = [{"label":"W","y":1548},{"label":"Vbg","y":680},{"label":"T","y":2462},{"label":"Stmk","y":1137},{"label":"Sbg","y":993},{"label":"OÖ","y":1739},{"label":"NÖ","y":1717},{"label":"Ktn","y":295},{"label":"Bgld","y":198}];
var BundeslandVersion = "02.04.2020 08:00:00 V 1.1.0.0"
