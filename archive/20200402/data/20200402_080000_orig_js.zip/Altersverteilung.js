var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":242},{"label":"15-24","y":998},{"label":"25-34","y":1550},{"label":"35-44","y":1576},{"label":"45-54","y":2293},{"label":"55-64","y":1858},{"label":">64","y":2206}];
var AltersverteilungVersion = "02.04.2020 08:00:00 V 1.1.0.0"
