var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":239},{"label":"15-24","y":992},{"label":"25-34","y":1546},{"label":"35-44","y":1569},{"label":"45-54","y":2283},{"label":"55-64","y":1852},{"label":">64","y":2191}];
var AltersverteilungVersion = "02.04.2020 07:00:00 V 1.1.0.0"
