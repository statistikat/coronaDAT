var dpBundesland = [{"label":"W","y":1553},{"label":"Vbg","y":680},{"label":"T","y":2511},{"label":"Stmk","y":1135},{"label":"Sbg","y":993},{"label":"OÖ","y":1748},{"label":"NÖ","y":1726},{"label":"Ktn","y":297},{"label":"Bgld","y":199}];
var BundeslandVersion = "02.04.2020 10:00:00 V 1.1.0.0"
