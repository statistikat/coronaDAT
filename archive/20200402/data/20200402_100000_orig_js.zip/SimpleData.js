var Erkrankungen = "10842";
var LetzteAktualisierung = "02.04.2020 10:00.00";
var SimpleDataVersion = "02.04.2020 10:00:00 V 1.1.0.0"
