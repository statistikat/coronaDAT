var Erkrankungen = "10809";
var LetzteAktualisierung = "02.04.2020 09:00.00";
var SimpleDataVersion = "02.04.2020 09:00:00 V 1.1.0.0"
