var dpBundesland = [{"label":"W","y":1553},{"label":"Vbg","y":680},{"label":"T","y":2478},{"label":"Stmk","y":1137},{"label":"Sbg","y":994},{"label":"OÖ","y":1749},{"label":"NÖ","y":1721},{"label":"Ktn","y":298},{"label":"Bgld","y":199}];
var BundeslandVersion = "02.04.2020 09:00:00 V 1.1.0.0"
