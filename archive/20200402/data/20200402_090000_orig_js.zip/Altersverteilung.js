var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":241},{"label":"15-24","y":1009},{"label":"25-34","y":1552},{"label":"35-44","y":1580},{"label":"45-54","y":2301},{"label":"55-64","y":1866},{"label":">64","y":2214}];
var AltersverteilungVersion = "02.04.2020 09:00:00 V 1.1.0.0"
