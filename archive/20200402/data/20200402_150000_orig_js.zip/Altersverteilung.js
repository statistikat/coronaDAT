var dpAltersverteilung = [{"label":"<5","y":46},{"label":"5-14","y":247},{"label":"15-24","y":1024},{"label":"25-34","y":1571},{"label":"35-44","y":1604},{"label":"45-54","y":2336},{"label":"55-64","y":1897},{"label":">64","y":2242}];
var AltersverteilungVersion = "02.04.2020 15:00:00 V 1.1.0.0"
