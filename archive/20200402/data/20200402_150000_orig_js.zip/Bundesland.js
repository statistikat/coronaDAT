var dpBundesland = [{"label":"W","y":1583},{"label":"Vbg","y":681},{"label":"T","y":2531},{"label":"Stmk","y":1158},{"label":"Sbg","y":994},{"label":"OÖ","y":1781},{"label":"NÖ","y":1738},{"label":"Ktn","y":300},{"label":"Bgld","y":201}];
var BundeslandVersion = "02.04.2020 15:00:00 V 1.1.0.0"
