var Erkrankungen = "10967";
var LetzteAktualisierung = "02.04.2020 15:00.00";
var SimpleDataVersion = "02.04.2020 15:00:00 V 1.1.0.0"
