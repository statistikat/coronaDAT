var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":274},{"label":"15-24","y":1102},{"label":"25-34","y":1711},{"label":"35-44","y":1726},{"label":"45-54","y":2537},{"label":"55-64","y":2028},{"label":">64","y":2465}];
var AltersverteilungVersion = "05.04.2020 14:00:00 V 1.1.0.0"
