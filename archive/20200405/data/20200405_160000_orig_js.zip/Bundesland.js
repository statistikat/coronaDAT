var dpBundesland = [{"label":"W","y":1701},{"label":"Vbg","y":742},{"label":"T","y":2708},{"label":"Stmk","y":1312},{"label":"Sbg","y":1069},{"label":"OÖ","y":1939},{"label":"NÖ","y":1903},{"label":"Ktn","y":319},{"label":"Bgld","y":227}];
var BundeslandVersion = "05.04.2020 16:00:00 V 1.1.0.0"
