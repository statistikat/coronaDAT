var dpGeschlechtsverteilung = [{"label":"männlich","y":51},{"label":"weiblich","y":49}];
var GeschlechtsverteilungVersion = "05.04.2020 00:00:00 V 1.1.0.0"
