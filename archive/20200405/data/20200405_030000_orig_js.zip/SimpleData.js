var Erkrankungen = "11766";
var LetzteAktualisierung = "05.04.2020 03:00.00";
var SimpleDataVersion = "05.04.2020 03:00:00 V 1.1.0.0"
