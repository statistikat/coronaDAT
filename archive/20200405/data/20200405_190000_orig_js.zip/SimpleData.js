var Erkrankungen = "11955";
var LetzteAktualisierung = "05.04.2020 19:00.00";
var SimpleDataVersion = "05.04.2020 19:00:00 V 1.1.0.0"
