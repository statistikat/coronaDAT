var dpBundesland = [{"label":"W","y":1701},{"label":"Vbg","y":742},{"label":"T","y":2704},{"label":"Stmk","y":1311},{"label":"Sbg","y":1069},{"label":"OÖ","y":1932},{"label":"NÖ","y":1903},{"label":"Ktn","y":319},{"label":"Bgld","y":226}];
var BundeslandVersion = "05.04.2020 15:00:00 V 1.1.0.0"
