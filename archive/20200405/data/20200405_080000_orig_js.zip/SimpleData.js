var Erkrankungen = "11767";
var LetzteAktualisierung = "05.04.2020 08:00.00";
var SimpleDataVersion = "05.04.2020 08:00:00 V 1.1.0.0"
