var dpBundesland = [{"label":"W","y":1689},{"label":"Vbg","y":722},{"label":"T","y":2690},{"label":"Stmk","y":1285},{"label":"Sbg","y":1068},{"label":"OÖ","y":1916},{"label":"NÖ","y":1863},{"label":"Ktn","y":310},{"label":"Bgld","y":224}];
var BundeslandVersion = "05.04.2020 08:00:00 V 1.1.0.0"
