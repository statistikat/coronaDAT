var Erkrankungen = "11973";
var LetzteAktualisierung = "05.04.2020 21:00.00";
var SimpleDataVersion = "05.04.2020 21:00:00 V 1.1.0.0"
