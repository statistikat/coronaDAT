var dpBundesland = [{"label":"W","y":1702},{"label":"Vbg","y":742},{"label":"T","y":2716},{"label":"Stmk","y":1312},{"label":"Sbg","y":1073},{"label":"OÖ","y":1940},{"label":"NÖ","y":1902},{"label":"Ktn","y":319},{"label":"Bgld","y":228}];
var BundeslandVersion = "05.04.2020 18:00:00 V 1.1.0.0"
