var Erkrankungen = "11934";
var LetzteAktualisierung = "05.04.2020 18:00.00";
var SimpleDataVersion = "05.04.2020 18:00:00 V 1.1.0.0"
