var dpBundesland = [{"label":"W","y":1691},{"label":"Vbg","y":737},{"label":"T","y":2693},{"label":"Stmk","y":1286},{"label":"Sbg","y":1068},{"label":"OÖ","y":1920},{"label":"NÖ","y":1901},{"label":"Ktn","y":311},{"label":"Bgld","y":224}];
var BundeslandVersion = "05.04.2020 11:00:00 V 1.1.0.0"
