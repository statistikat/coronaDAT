var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":273},{"label":"15-24","y":1099},{"label":"25-34","y":1700},{"label":"35-44","y":1712},{"label":"45-54","y":2524},{"label":"55-64","y":2021},{"label":">64","y":2448}];
var AltersverteilungVersion = "05.04.2020 11:00:00 V 1.1.0.0"
