var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":274},{"label":"15-24","y":1100},{"label":"25-34","y":1704},{"label":"35-44","y":1720},{"label":"45-54","y":2526},{"label":"55-64","y":2024},{"label":">64","y":2459}];
var AltersverteilungVersion = "05.04.2020 13:00:00 V 1.1.0.0"
