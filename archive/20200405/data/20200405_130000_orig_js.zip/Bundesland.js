var dpBundesland = [{"label":"W","y":1698},{"label":"Vbg","y":738},{"label":"T","y":2704},{"label":"Stmk","y":1292},{"label":"Sbg","y":1068},{"label":"OÖ","y":1921},{"label":"NÖ","y":1902},{"label":"Ktn","y":314},{"label":"Bgld","y":224}];
var BundeslandVersion = "05.04.2020 13:00:00 V 1.1.0.0"
