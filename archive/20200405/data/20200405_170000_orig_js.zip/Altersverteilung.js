var dpAltersverteilung = [{"label":"<5","y":54},{"label":"5-14","y":276},{"label":"15-24","y":1107},{"label":"25-34","y":1715},{"label":"35-44","y":1731},{"label":"45-54","y":2544},{"label":"55-64","y":2033},{"label":">64","y":2470}];
var AltersverteilungVersion = "05.04.2020 17:00:00 V 1.1.0.0"
