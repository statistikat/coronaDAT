var Erkrankungen = "12613";
var LetzteAktualisierung = "07.04.2020 19:00.00";
var SimpleDataVersion = "07.04.2020 19:00:00 V 1.1.0.0"
