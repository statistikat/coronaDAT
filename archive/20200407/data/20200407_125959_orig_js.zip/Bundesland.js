var dpBundesland = [{"label":"W","y":1786},{"label":"Vbg","y":765},{"label":"T","y":2828},{"label":"Stmk","y":1370},{"label":"Sbg","y":1091},{"label":"OÖ","y":1987},{"label":"NÖ","y":2065},{"label":"Ktn","y":335},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 12:59:59 V 1.1.0.0"
