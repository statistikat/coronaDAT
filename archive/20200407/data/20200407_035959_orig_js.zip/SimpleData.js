var Erkrankungen = "12297";
var LetzteAktualisierung = "07.04.2020 03:59.59";
var SimpleDataVersion = "07.04.2020 03:59:59 V 1.1.0.0"
