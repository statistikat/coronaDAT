var dpBundesland = [{"label":"W","y":1815},{"label":"Vbg","y":768},{"label":"T","y":2843},{"label":"Stmk","y":1384},{"label":"Sbg","y":1095},{"label":"OÖ","y":1995},{"label":"NÖ","y":2072},{"label":"Ktn","y":341},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 16:00:00 V 1.1.0.0"
