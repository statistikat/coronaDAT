var Erkrankungen = "12547";
var LetzteAktualisierung = "07.04.2020 16:00.00";
var SimpleDataVersion = "07.04.2020 16:00:00 V 1.1.0.0"
