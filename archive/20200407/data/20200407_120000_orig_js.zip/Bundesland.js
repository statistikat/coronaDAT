var dpBundesland = [{"label":"W","y":1785},{"label":"Vbg","y":765},{"label":"T","y":2819},{"label":"Stmk","y":1355},{"label":"Sbg","y":1090},{"label":"OÖ","y":1982},{"label":"NÖ","y":2064},{"label":"Ktn","y":333},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 12:00:00 V 1.1.0.0"
