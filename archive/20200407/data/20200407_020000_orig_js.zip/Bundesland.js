var dpBundesland = [{"label":"W","y":1770},{"label":"Vbg","y":760},{"label":"T","y":2786},{"label":"Stmk","y":1351},{"label":"Sbg","y":1085},{"label":"OÖ","y":1974},{"label":"NÖ","y":2010},{"label":"Ktn","y":329},{"label":"Bgld","y":232}];
var BundeslandVersion = "07.04.2020 02:00:00 V 1.1.0.0"
