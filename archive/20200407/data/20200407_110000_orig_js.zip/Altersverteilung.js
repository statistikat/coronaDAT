var dpAltersverteilung = [{"label":"<5","y":56},{"label":"5-14","y":286},{"label":"15-24","y":1157},{"label":"25-34","y":1769},{"label":"35-44","y":1781},{"label":"45-54","y":2637},{"label":"55-64","y":2102},{"label":">64","y":2611}];
var AltersverteilungVersion = "07.04.2020 11:00:00 V 1.1.0.0"
