var dpBundesland = [{"label":"W","y":1777},{"label":"Vbg","y":764},{"label":"T","y":2808},{"label":"Stmk","y":1354},{"label":"Sbg","y":1085},{"label":"OÖ","y":1980},{"label":"NÖ","y":2064},{"label":"Ktn","y":333},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 11:00:00 V 1.1.0.0"
