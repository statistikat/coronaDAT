var dpBundesland = [{"label":"W","y":1813},{"label":"Vbg","y":768},{"label":"T","y":2835},{"label":"Stmk","y":1372},{"label":"Sbg","y":1094},{"label":"OÖ","y":1991},{"label":"NÖ","y":2071},{"label":"Ktn","y":341},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 15:00:00 V 1.1.0.0"
