var dpAltersverteilung = [{"label":"<5","y":56},{"label":"5-14","y":286},{"label":"15-24","y":1168},{"label":"25-34","y":1781},{"label":"35-44","y":1794},{"label":"45-54","y":2664},{"label":"55-64","y":2125},{"label":">64","y":2645}];
var AltersverteilungVersion = "07.04.2020 15:00:00 V 1.1.0.0"
