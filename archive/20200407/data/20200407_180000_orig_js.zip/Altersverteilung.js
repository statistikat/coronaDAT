var dpAltersverteilung = [{"label":"<5","y":56},{"label":"5-14","y":287},{"label":"15-24","y":1172},{"label":"25-34","y":1785},{"label":"35-44","y":1799},{"label":"45-54","y":2674},{"label":"55-64","y":2143},{"label":">64","y":2683}];
var AltersverteilungVersion = "07.04.2020 18:00:00 V 1.1.0.0"
