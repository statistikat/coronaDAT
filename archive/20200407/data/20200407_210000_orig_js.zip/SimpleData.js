var Erkrankungen = "12633";
var LetzteAktualisierung = "07.04.2020 21:00.00";
var SimpleDataVersion = "07.04.2020 21:00:00 V 1.1.0.0"
