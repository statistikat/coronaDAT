var dpAltersverteilung = [{"label":"<5","y":55},{"label":"5-14","y":284},{"label":"15-24","y":1144},{"label":"25-34","y":1764},{"label":"35-44","y":1773},{"label":"45-54","y":2623},{"label":"55-64","y":2096},{"label":">64","y":2593}];
var AltersverteilungVersion = "07.04.2020 08:00:00 V 1.1.0.0"
