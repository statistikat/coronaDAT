var dpBundesland = [{"label":"W","y":1802},{"label":"Vbg","y":768},{"label":"T","y":2829},{"label":"Stmk","y":1372},{"label":"Sbg","y":1091},{"label":"OÖ","y":1987},{"label":"NÖ","y":2067},{"label":"Ktn","y":338},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 14:00:00 V 1.1.0.0"
