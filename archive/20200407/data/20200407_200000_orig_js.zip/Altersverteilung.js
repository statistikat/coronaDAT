var dpAltersverteilung = [{"label":"<5","y":57},{"label":"5-14","y":287},{"label":"15-24","y":1173},{"label":"25-34","y":1786},{"label":"35-44","y":1803},{"label":"45-54","y":2677},{"label":"55-64","y":2146},{"label":">64","y":2687}];
var AltersverteilungVersion = "07.04.2020 20:00:00 V 1.1.0.0"
