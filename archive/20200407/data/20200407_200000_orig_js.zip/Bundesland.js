var dpBundesland = [{"label":"W","y":1820},{"label":"Vbg","y":777},{"label":"T","y":2854},{"label":"Stmk","y":1396},{"label":"Sbg","y":1111},{"label":"OÖ","y":2006},{"label":"NÖ","y":2076},{"label":"Ktn","y":341},{"label":"Bgld","y":235}];
var BundeslandVersion = "07.04.2020 20:00:00 V 1.1.0.0"
