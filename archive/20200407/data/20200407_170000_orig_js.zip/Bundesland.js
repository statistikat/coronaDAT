var dpBundesland = [{"label":"W","y":1819},{"label":"Vbg","y":777},{"label":"T","y":2850},{"label":"Stmk","y":1393},{"label":"Sbg","y":1108},{"label":"OÖ","y":1995},{"label":"NÖ","y":2075},{"label":"Ktn","y":341},{"label":"Bgld","y":234}];
var BundeslandVersion = "07.04.2020 17:00:00 V 1.1.0.0"
