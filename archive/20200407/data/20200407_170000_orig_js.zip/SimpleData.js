var Erkrankungen = "12592";
var LetzteAktualisierung = "07.04.2020 17:00.00";
var SimpleDataVersion = "07.04.2020 17:00:00 V 1.1.0.0"
