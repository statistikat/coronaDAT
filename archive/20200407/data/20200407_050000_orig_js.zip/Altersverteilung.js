var dpAltersverteilung = [{"label":"<5","y":55},{"label":"5-14","y":284},{"label":"15-24","y":1138},{"label":"25-34","y":1758},{"label":"35-44","y":1771},{"label":"45-54","y":2612},{"label":"55-64","y":2092},{"label":">64","y":2587}];
var AltersverteilungVersion = "07.04.2020 05:00:00 V 1.1.0.0"
