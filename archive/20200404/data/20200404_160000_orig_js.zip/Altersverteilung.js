var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":264},{"label":"15-24","y":1089},{"label":"25-34","y":1675},{"label":"35-44","y":1696},{"label":"45-54","y":2490},{"label":"55-64","y":1992},{"label":">64","y":2420}];
var AltersverteilungVersion = "04.04.2020 16:00:00 V 1.1.0.0"
