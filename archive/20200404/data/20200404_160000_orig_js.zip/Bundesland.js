var dpBundesland = [{"label":"W","y":1684},{"label":"Vbg","y":722},{"label":"T","y":2655},{"label":"Stmk","y":1268},{"label":"Sbg","y":1059},{"label":"OÖ","y":1894},{"label":"NÖ","y":1862},{"label":"Ktn","y":310},{"label":"Bgld","y":225}];
var BundeslandVersion = "04.04.2020 16:00:00 V 1.1.0.0"
