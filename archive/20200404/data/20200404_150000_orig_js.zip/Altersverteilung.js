var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":263},{"label":"15-24","y":1088},{"label":"25-34","y":1674},{"label":"35-44","y":1694},{"label":"45-54","y":2490},{"label":"55-64","y":1989},{"label":">64","y":2414}];
var AltersverteilungVersion = "04.04.2020 15:00:00 V 1.1.0.0"
