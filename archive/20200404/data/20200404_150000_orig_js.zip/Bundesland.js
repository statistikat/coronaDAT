var dpBundesland = [{"label":"W","y":1679},{"label":"Vbg","y":722},{"label":"T","y":2658},{"label":"Stmk","y":1263},{"label":"Sbg","y":1059},{"label":"OÖ","y":1890},{"label":"NÖ","y":1860},{"label":"Ktn","y":310},{"label":"Bgld","y":224}];
var BundeslandVersion = "04.04.2020 15:00:00 V 1.1.0.0"
