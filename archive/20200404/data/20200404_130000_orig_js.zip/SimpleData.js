var Erkrankungen = "11611";
var LetzteAktualisierung = "04.04.2020 13:00.00";
var SimpleDataVersion = "04.04.2020 13:00:00 V 1.1.0.0"
