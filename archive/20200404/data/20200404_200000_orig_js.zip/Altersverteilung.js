var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":269},{"label":"15-24","y":1097},{"label":"25-34","y":1682},{"label":"35-44","y":1708},{"label":"45-54","y":2506},{"label":"55-64","y":2005},{"label":">64","y":2433}];
var AltersverteilungVersion = "04.04.2020 20:00:00 V 1.1.0.0"
