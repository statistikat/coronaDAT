var dpBundesland = [{"label":"W","y":1688},{"label":"Vbg","y":722},{"label":"T","y":2683},{"label":"Stmk","y":1285},{"label":"Sbg","y":1063},{"label":"OÖ","y":1915},{"label":"NÖ","y":1863},{"label":"Ktn","y":310},{"label":"Bgld","y":224}];
var BundeslandVersion = "04.04.2020 20:00:00 V 1.1.0.0"
