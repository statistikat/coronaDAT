var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":270},{"label":"15-24","y":1098},{"label":"25-34","y":1686},{"label":"35-44","y":1709},{"label":"45-54","y":2508},{"label":"55-64","y":2009},{"label":">64","y":2433}];
var AltersverteilungVersion = "04.04.2020 23:00:00 V 1.1.0.0"
