var dpBundesland = [{"label":"W","y":1678},{"label":"Vbg","y":718},{"label":"T","y":2652},{"label":"Stmk","y":1237},{"label":"Sbg","y":1058},{"label":"OÖ","y":1876},{"label":"NÖ","y":1862},{"label":"Ktn","y":308},{"label":"Bgld","y":217}];
var BundeslandVersion = "04.04.2020 12:00:00 V 1.1.0.0"
