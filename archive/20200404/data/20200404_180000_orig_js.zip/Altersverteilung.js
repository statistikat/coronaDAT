var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":267},{"label":"15-24","y":1094},{"label":"25-34","y":1678},{"label":"35-44","y":1703},{"label":"45-54","y":2498},{"label":"55-64","y":1997},{"label":">64","y":2423}];
var AltersverteilungVersion = "04.04.2020 18:00:00 V 1.1.0.0"
