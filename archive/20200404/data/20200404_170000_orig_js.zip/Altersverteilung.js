var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":265},{"label":"15-24","y":1093},{"label":"25-34","y":1677},{"label":"35-44","y":1701},{"label":"45-54","y":2497},{"label":"55-64","y":1994},{"label":">64","y":2422}];
var AltersverteilungVersion = "04.04.2020 17:00:00 V 1.1.0.0"
