var Erkrankungen = "11525";
var LetzteAktualisierung = "04.04.2020 06:00.00";
var SimpleDataVersion = "04.04.2020 06:00:00 V 1.1.0.0"
