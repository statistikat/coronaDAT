var dpBundesland = [{"label":"W","y":1679},{"label":"Vbg","y":718},{"label":"T","y":2645},{"label":"Stmk","y":1234},{"label":"Sbg","y":1058},{"label":"OÖ","y":1869},{"label":"NÖ","y":1862},{"label":"Ktn","y":307},{"label":"Bgld","y":217}];
var BundeslandVersion = "04.04.2020 10:00:00 V 1.1.0.0"
