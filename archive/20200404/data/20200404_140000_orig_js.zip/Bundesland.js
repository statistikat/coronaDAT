var dpBundesland = [{"label":"W","y":1678},{"label":"Vbg","y":722},{"label":"T","y":2654},{"label":"Stmk","y":1249},{"label":"Sbg","y":1058},{"label":"OÖ","y":1888},{"label":"NÖ","y":1863},{"label":"Ktn","y":310},{"label":"Bgld","y":224}];
var BundeslandVersion = "04.04.2020 14:00:00 V 1.1.0.0"
