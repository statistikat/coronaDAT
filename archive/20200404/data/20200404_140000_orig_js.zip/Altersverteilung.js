var dpAltersverteilung = [{"label":"<5","y":53},{"label":"5-14","y":263},{"label":"15-24","y":1089},{"label":"25-34","y":1673},{"label":"35-44","y":1689},{"label":"45-54","y":2485},{"label":"55-64","y":1989},{"label":">64","y":2405}];
var AltersverteilungVersion = "04.04.2020 14:00:00 V 1.1.0.0"
