var dpBundesland = [{"label":"W","y":1677},{"label":"Vbg","y":715},{"label":"T","y":2633},{"label":"Stmk","y":1226},{"label":"Sbg","y":1057},{"label":"OÖ","y":1868},{"label":"NÖ","y":1831},{"label":"Ktn","y":307},{"label":"Bgld","y":210}];
var BundeslandVersion = "04.04.2020 01:00:00 V 1.1.0.0"
