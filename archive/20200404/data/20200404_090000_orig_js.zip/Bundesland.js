var dpBundesland = [{"label":"W","y":1678},{"label":"Vbg","y":718},{"label":"T","y":2643},{"label":"Stmk","y":1226},{"label":"Sbg","y":1058},{"label":"OÖ","y":1869},{"label":"NÖ","y":1835},{"label":"Ktn","y":307},{"label":"Bgld","y":210}];
var BundeslandVersion = "04.04.2020 09:00:00 V 1.1.0.0"
