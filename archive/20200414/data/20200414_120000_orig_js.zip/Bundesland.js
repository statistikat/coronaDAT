var dpBundesland = [{"label":"W","y":2041},{"label":"Vbg","y":832},{"label":"T","y":3317},{"label":"Stmk","y":1585},{"label":"Sbg","y":1173},{"label":"OÖ","y":2135},{"label":"NÖ","y":2381},{"label":"Ktn","y":385},{"label":"Bgld","y":270}];
var BundeslandVersion = "14.04.2020 12:00:00 V 1.1.0.0"
