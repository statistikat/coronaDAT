﻿var Erkrankungen = "14128";
var LetzteAktualisierung = "14.04.2020 12:49.21";
var SimpleDataVersion = "14.04.2020 12:49:21 V 1.0.0.0"
