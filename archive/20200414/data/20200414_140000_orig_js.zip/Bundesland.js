var dpBundesland = [{"label":"W","y":2051},{"label":"Vbg","y":832},{"label":"T","y":3323},{"label":"Stmk","y":1588},{"label":"Sbg","y":1173},{"label":"OÖ","y":2140},{"label":"NÖ","y":2382},{"label":"Ktn","y":386},{"label":"Bgld","y":271}];
var BundeslandVersion = "14.04.2020 14:00:00 V 1.1.0.0"
