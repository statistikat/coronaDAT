var dpAltersverteilung = [{"label":"<5","y":72},{"label":"5-14","y":316},{"label":"15-24","y":1323},{"label":"25-34","y":1963},{"label":"35-44","y":1982},{"label":"45-54","y":2995},{"label":"55-64","y":2389},{"label":">64","y":3106}];
var AltersverteilungVersion = "14.04.2020 14:00:00 V 1.1.0.0"
