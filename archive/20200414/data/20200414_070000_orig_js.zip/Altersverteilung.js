var dpAltersverteilung = [{"label":"<5","y":71},{"label":"5-14","y":315},{"label":"15-24","y":1317},{"label":"25-34","y":1954},{"label":"35-44","y":1968},{"label":"45-54","y":2975},{"label":"55-64","y":2375},{"label":">64","y":3070}];
var AltersverteilungVersion = "14.04.2020 07:00:00 V 1.1.0.0"
