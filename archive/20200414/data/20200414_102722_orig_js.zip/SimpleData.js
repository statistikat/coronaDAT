var Erkrankungen = "14102";
var LetzteAktualisierung = "14.04.2020 10:27.22";
var SimpleDataVersion = "14.04.2020 10:27:22 V 1.1.0.0"
