var dpBundesland = [{"label":"W","y":2053},{"label":"Vbg","y":832},{"label":"T","y":3328},{"label":"Stmk","y":1588},{"label":"Sbg","y":1174},{"label":"OÖ","y":2140},{"label":"NÖ","y":2387},{"label":"Ktn","y":386},{"label":"Bgld","y":271}];
var BundeslandVersion = "14.04.2020 15:00:00 V 1.1.0.0"
