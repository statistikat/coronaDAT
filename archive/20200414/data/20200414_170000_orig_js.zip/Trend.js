<!doctype html>
<html lang="en">
<head>
    <title>Amtliches Dashboard COVID19</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="version" content="1.1..0">
    <meta http-equiv="refresh" content="1800">
    <script type="text/javascript" src="./data/Epikurve.js"></script>
    <!-- style -->
    <script type="text/javascript" src="./css/bootstrap/js/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/styles.css">
    <link rel="stylesheet" href="./css/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/bootstrap/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="./css/bootstrap/css/bootstrap-reboot.min.css">
    <script type="text/javascript" src="./css/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="./scripts/l10n.js"></script>

    <script>
         //let searchParams = new URLSearchParams(location.search);

        $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(location.search);
            if (results == null) {
                return null;
            }
            else {
                return decodeURI(results[1]) || 0;
            }
        }

        const lang = $.urlParam('l');
        const l10n = languageLabels[lang] ? languageLabels[lang] : languageLabels.de;

        window.onload = function () {
            var chart4 = new CanvasJS.Chart("cEpikurve", {
                animationEnabled: true,
                culture: "at",
                theme: "dark1",
                title: {
                    text: l10n.r35, fontFamily: "calibri", fontSize: 20, fontWeight: "normal"
                },
                axisY: {
                    includeZero: true
                },
                data: [{
                    type: "column",
                    color: "#47ba85",
                    dataPoints: dpEpikurve
                }]
            });
            chart4.render();
        }

    </script>
</head>
<body class="bg-dark text-white">
    <header class="mb-4">

        <nav class="navbar navbar-expand-lg navbar-dark mb-4 firstnav" style="background-color: black;">
            <div class="container">
                <a class="navbar-brand" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation" data-l10n="r30">Datenblätter</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample07">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="dashboard.html" data-l10n-href="r26" data-l10n="r31">Überblick <span class="sr-only">(aktuell)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard_Epidem.html" data-l10n-href="r27" data-l10n="r32">Epidemiologische Daten</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard_Hosp.html" data-l10n-href="r28" data-l10n="r33">Hospitalisierungen</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard_GenTod.html" data-l10n-href="r29" data-l10n="r34">Genesene und Todesfälle</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav mr-0 trenner">
                        <li class="nav-item" id="lang-de-btn">
                            <a class="nav-link" href="./data/data.zip" data-l10n="r61"></a>
                        </li>
                        <li class="nav-item" id="lang-de-btn">
                            <a class="nav-link" href="?l=de">DE</a>
                        </li>
                        <li class="nav-item" id="lang-en-btn">
                            <a class="nav-link" href="?l=en">EN</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4 col-xl-4 mb-4">
                    <img src="./images/BMSGPK-Logo_background.png" style="max-width: 100%" alt="Bundesministerium Soziales, Gesundheit, Pflege und Konsumentenschutz" />
                </div>
                <div class="col">
                    <h1 class="text-center" data-l10n="r00">Amtliches Dashboard COVID19</h1>
                    <h2 class="text-center" data-l10n="r01">öffentlich zugängliche Informationen</h2>
                </div>
            </div>
        </div>

    </header>
    <main role="main" class="my-4">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <p class="card-text">
                                <div id="cEpikurve" class="h-400"></div>
                            </p>
                        </div>
                        <div class="card-footer border-top border-light" style="color: #aaa;">
                            <p data-l10n="r37">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque tempor, nibh nec facilisis mattis, nulla nunc varius nibh, non feugiat lacus arcu eget eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis semper dui at ipsum dictum imperdiet et a metus.</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="my-4">
        <div class="container">
            <div class="row">
                <div class="card-body">
                    <p class="card-text" data-l10n="r02">
                        Wir arbeiten laufend an der Optimierung. Als Quelle für alle Diagramme dienen ausschließlich die geprüften und validierten Daten gemäß Epidemiegesetz. Die Daten werden von den Bezirksverwaltungsbehörden zur Verfügung gestellt. Bei der Übermittlung der Fälle kann es zu Verzögerungen in der Darstellung kommen.
                    </p>
                </div>
            </div>
        </div>

        <p class="text-center">© Bundesministerium für Soziales, Gesundheit, Pflege und Konsumentenschutz</p>
        <nav class="navbar navbar-expand navbar-dark bg-dark">
            <div class="collapse navbar-collapse justify-content-center">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.sozialministerium.at/Ministerium/Kontakt/Impressum.html" target="_blank" data-l10n="r22">Impressum</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.sozialministerium.at/Ministerium/Rechtliches-und-Foerderungen/Datenschutz.html" target="_blank" data-l10n="r23">Datenschutz</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.sozialministerium.at/Informationen-zum-Coronavirus/Dashboard.html" target="_blank" data-l10n="r24" data-l10n-href="r25">Erläuterungen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Basisinformationen.pdf" target="_blank" data-l10n="r62" data-l10n-href="r63">Basisinformation</a>
                    </li>
                </ul>
            </div>
        </nav>
    </footer>
    <script>
        $(function () {

            $('[data-l10n]').each(function () {
                let key = $(this).data('l10n');
                $(this).text(l10n[key]);
            });
            $('[data-l10n-title]').each(function () {
                let key = $(this).data('l10n-title');
                $(this).attr('title', l10n[key]);
            });
            $('[data-l10n-href]').each(function () {
                let key = $(this).data('l10n-href');
                $(this).attr('href', l10n[key]);
            });
            if (lang == 'en') {
                $('#lang-en-btn').addClass('active');
            } else {
                $('#lang-de-btn').addClass('active');
            }
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>
    <script src="./scripts/canvasjs.min.js"></script>
    <script src="./scripts/d3.v3.min.js"></script>
    <script src="./scripts/queue.v1.min.js"></script>
    <script src="./scripts/d3-legend.min.js"></script>
    <script src="./scripts/topojson.v1.min.js"></script>
    <script src="./scripts/d3.tip.v0.6.3.js"></script>
    <script src="./scripts/script.js"></script>
    <!-- Matomo -->
    <script type="text/javascript">

        var _paq = window._paq || [];
        /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
        _paq.push(["setDocumentTitle", document.domain + "/" + document.title]);
        _paq.push(["setCookieDomain", "*.info.gesundheitsministerium.at"]);
        _paq.push(["setDomains", ["*.info.gesundheitsministerium.at", "*.info.gesundheitsministerium.gv.at"]]);
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        (function () {
            var u = "//an.ehealth.gv.at/";
            _paq.push(['setTrackerUrl', u + 'matomo.php']);
            _paq.push(['setSiteId', '7']);
            var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
            g.type = 'text/javascript'; g.async = true; g.defer = true; g.src = u + 'matomo.js'; s.parentNode.insertBefore(g, s);
        })();
    </script>
    <noscript><p><img src="//an.ehealth.gv.at/matomo.php?idsite=7&amp;rec=1" style="border:0;" alt="" /></p></noscript>
    <!-- End Matomo Code -->
</body>
</html>
