var dpBundesland = [{"label":"W","y":2035},{"label":"Vbg","y":832},{"label":"T","y":3317},{"label":"Stmk","y":1578},{"label":"Sbg","y":1173},{"label":"OÖ","y":2135},{"label":"NÖ","y":2380},{"label":"Ktn","y":386},{"label":"Bgld","y":270}];
var BundeslandVersion = "14.04.2020 11:00:00 V 1.1.0.0"
