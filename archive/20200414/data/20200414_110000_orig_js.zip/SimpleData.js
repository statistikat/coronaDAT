var Erkrankungen = "14106";
var LetzteAktualisierung = "14.04.2020 11:00.00";
var SimpleDataVersion = "14.04.2020 11:00:00 V 1.1.0.0"
