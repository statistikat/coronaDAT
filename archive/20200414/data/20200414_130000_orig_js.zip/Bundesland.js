var dpBundesland = [{"label":"W","y":2045},{"label":"Vbg","y":832},{"label":"T","y":3323},{"label":"Stmk","y":1586},{"label":"Sbg","y":1173},{"label":"OÖ","y":2139},{"label":"NÖ","y":2381},{"label":"Ktn","y":386},{"label":"Bgld","y":270}];
var BundeslandVersion = "14.04.2020 13:00:00 V 1.1.0.0"
