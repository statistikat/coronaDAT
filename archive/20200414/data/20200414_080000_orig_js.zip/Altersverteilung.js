var dpAltersverteilung = [{"label":"<5","y":71},{"label":"5-14","y":315},{"label":"15-24","y":1318},{"label":"25-34","y":1956},{"label":"35-44","y":1969},{"label":"45-54","y":2977},{"label":"55-64","y":2380},{"label":">64","y":3074}];
var AltersverteilungVersion = "14.04.2020 08:00:00 V 1.1.0.0"
