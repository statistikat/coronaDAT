var dpGeschlechtsverteilung = [{"label":"weiblich","y":51,"CSV":"weiblich;51"},{"label":"männlich","y":49,"CSV":"männlich;49"}];
var GeschlechtsverteilungVersion = "14.04.2020 16:01:17 V 1.0.0.0"
