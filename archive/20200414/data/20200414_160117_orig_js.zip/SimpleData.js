var Erkrankungen = "14170";
var LetzteAktualisierung = "14.04.2020 16:01.17";
var SimpleDataVersion = "14.04.2020 16:01:17 V 1.0.0.0"
