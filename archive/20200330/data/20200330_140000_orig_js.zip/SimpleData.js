var Erkrankungen = 9299;
var LetzteAktualisierung = "30.03.2020 14:00.00";
