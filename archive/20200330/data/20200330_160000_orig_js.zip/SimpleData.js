var Erkrankungen = 9424;
var LetzteAktualisierung = "30.03.2020 16:00.00";
