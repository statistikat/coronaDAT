var Erkrankungen = 9597;
var LetzteAktualisierung = "30.03.2020 20:00.00";
