var Erkrankungen = 9454;
var LetzteAktualisierung = "30.03.2020 17:00.00";
