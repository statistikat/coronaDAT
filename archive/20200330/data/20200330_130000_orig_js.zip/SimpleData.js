var Erkrankungen = 9200;
var LetzteAktualisierung = "30.03.2020 13:00.00";
