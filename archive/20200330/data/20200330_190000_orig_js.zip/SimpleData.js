var Erkrankungen = 9541;
var LetzteAktualisierung = "30.03.2020 19:00.00";
