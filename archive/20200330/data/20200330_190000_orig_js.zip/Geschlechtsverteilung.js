var dpGeschlechtsverteilung = [{"label":"männlich","y":52},{"label":"weiblich","y":48}];
