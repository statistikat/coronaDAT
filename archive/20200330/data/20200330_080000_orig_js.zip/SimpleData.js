var Erkrankungen = 8813;
var LetzteAktualisierung = "30.03.2020 08:00.00";
