var Erkrankungen = 9520;
var LetzteAktualisierung = "30.03.2020 18:00.00";
