var Erkrankungen = 9103;
var LetzteAktualisierung = "30.03.2020 12:00.00";
