var Erkrankungen = 9618;
var LetzteAktualisierung = "30.03.2020 22:00.00";
