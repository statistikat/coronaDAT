var Erkrankungen = 9603;
var LetzteAktualisierung = "30.03.2020 21:00.00";
