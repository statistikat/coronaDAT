var Erkrankungen = 9377;
var LetzteAktualisierung = "30.03.2020 15:00.00";
