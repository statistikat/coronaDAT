var Erkrankungen = 8788;
var LetzteAktualisierung = "30.03.2020 03:00.00";
