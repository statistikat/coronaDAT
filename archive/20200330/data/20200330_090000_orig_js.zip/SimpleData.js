var Erkrankungen = 8867;
var LetzteAktualisierung = "30.03.2020 09:00.00";
