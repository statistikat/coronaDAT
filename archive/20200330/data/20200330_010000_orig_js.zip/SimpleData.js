var Erkrankungen = 8788;
var LetzteAktualisierung = "30.03.2020 01:00.00";
