var Erkrankungen = 8958;
var LetzteAktualisierung = "30.03.2020 10:00.00";
