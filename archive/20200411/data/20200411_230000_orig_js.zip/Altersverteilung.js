var dpAltersverteilung = [{"label":"<5","y":70},{"label":"5-14","y":310},{"label":"15-24","y":1297},{"label":"25-34","y":1932},{"label":"35-44","y":1945},{"label":"45-54","y":2923},{"label":"55-64","y":2332},{"label":">64","y":2997}];
var AltersverteilungVersion = "11.04.2020 23:00:00 V 1.1.0.0"
