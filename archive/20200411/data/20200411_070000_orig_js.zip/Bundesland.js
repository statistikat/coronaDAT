var dpBundesland = [{"label":"W","y":1962},{"label":"Vbg","y":819},{"label":"T","y":3176},{"label":"Stmk","y":1499},{"label":"Sbg","y":1154},{"label":"OÖ","y":2109},{"label":"NÖ","y":2213},{"label":"Ktn","y":373},{"label":"Bgld","y":255}];
var BundeslandVersion = "11.04.2020 07:00:00 V 1.1.0.0"
