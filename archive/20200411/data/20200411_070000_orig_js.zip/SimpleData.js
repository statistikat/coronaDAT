var Erkrankungen = "13560";
var LetzteAktualisierung = "11.04.2020 07:00.00";
var SimpleDataVersion = "11.04.2020 07:00:00 V 1.1.0.0"
