var dpBundesland = [{"label":"W","y":1996},{"label":"Vbg","y":825},{"label":"T","y":3260},{"label":"Stmk","y":1524},{"label":"Sbg","y":1157},{"label":"OÖ","y":2118},{"label":"NÖ","y":2281},{"label":"Ktn","y":382},{"label":"Bgld","y":259}];
var BundeslandVersion = "11.04.2020 22:00:00 V 1.1.0.0"
