var Erkrankungen = 9825;
var LetzteAktualisierung = "31.03.2020 11:00.00";
