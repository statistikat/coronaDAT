var dpBundesland = [{"label":"W","y":1390},{"label":"Vbg","y":646},{"label":"T","y":2334},{"label":"Stmk","y":1049},{"label":"Sbg","y":917},{"label":"OÖ","y":1599},{"label":"NÖ","y":1629},{"label":"Ktn","y":273},{"label":"Bgld","y":182}];
var BundeslandVersion = "31.03.2020 16:00:00 V 1.1.0.0"
