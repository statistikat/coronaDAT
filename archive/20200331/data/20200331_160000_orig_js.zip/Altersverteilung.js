var dpAltersverteilung = [{"label":"<5","y":41},{"label":"5-14","y":214},{"label":"15-24","y":922},{"label":"25-34","y":1476},{"label":"35-44","y":1472},{"label":"45-54","y":2133},{"label":"55-64","y":1732},{"label":">64","y":2029}];
var AltersverteilungVersion = "31.03.2020 16:00:00 V 1.1.0.0"
