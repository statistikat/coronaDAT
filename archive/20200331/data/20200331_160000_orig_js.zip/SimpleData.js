var Erkrankungen = "10019";
var LetzteAktualisierung = "31.03.2020 16:00.00";
var SimpleDataVersion = "31.03.2020 16:00:00 V 1.1.0.0"
