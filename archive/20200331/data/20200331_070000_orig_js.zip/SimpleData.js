var Erkrankungen = 9619;
var LetzteAktualisierung = "31.03.2020 07:00.00";
