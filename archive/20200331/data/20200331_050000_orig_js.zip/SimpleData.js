var Erkrankungen = 9618;
var LetzteAktualisierung = "31.03.2020 05:00.00";
