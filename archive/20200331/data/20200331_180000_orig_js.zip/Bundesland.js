var dpBundesland = [{"label":"W","y":1405},{"label":"Vbg","y":646},{"label":"T","y":2357},{"label":"Stmk","y":1060},{"label":"Sbg","y":917},{"label":"OÖ","y":1612},{"label":"NÖ","y":1633},{"label":"Ktn","y":273},{"label":"Bgld","y":185}];
var BundeslandVersion = "31.03.2020 18:00:00 V 1.1.0.0"
