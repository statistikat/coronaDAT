var Erkrankungen = "10088";
var LetzteAktualisierung = "31.03.2020 18:00.00";
var SimpleDataVersion = "31.03.2020 18:00:00 V 1.1.0.0"
