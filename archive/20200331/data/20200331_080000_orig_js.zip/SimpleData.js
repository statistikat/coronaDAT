var Erkrankungen = 9634;
var LetzteAktualisierung = "31.03.2020 08:00.00";
