var Erkrankungen = "9876";
var LetzteAktualisierung = "31.03.2020 13:00.00";
var SimpleDataVersion = "31.03.2020 13:00:00 V 1.0.0.0"
