var dpBundesland = [{"label":"Bgld","y":182},{"label":"Ktn","y":270},{"label":"NÖ","y":1594},{"label":"OÖ","y":1576},{"label":"Sbg","y":910},{"label":"Stmk","y":1028},{"label":"T","y":2319},{"label":"Vbg","y":637},{"label":"W","y":1360}];
var BundeslandVersion = "31.03.2020 13:00:00 V 1.0.0.0"
