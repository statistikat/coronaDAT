var dpBundesland = [{"label":"Bgld","y":182},{"label":"Ktn","y":273},{"label":"NÖ","y":1616},{"label":"OÖ","y":1596},{"label":"Sbg","y":911},{"label":"Stmk","y":1049},{"label":"T","y":2323},{"label":"Vbg","y":646},{"label":"W","y":1378}];
var BundeslandVersion = "31.03.2020 15:00:00 V 1.0.0.0"
