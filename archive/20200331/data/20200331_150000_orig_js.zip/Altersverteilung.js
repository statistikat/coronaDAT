var dpAltersverteilung = [{"label":"<5","y":41},{"label":"5-14","y":213},{"label":"15-24","y":917},{"label":"25-34","y":1471},{"label":"35-44","y":1464},{"label":"45-54","y":2123},{"label":"55-64","y":1727},{"label":">64","y":2018}];
var AltersverteilungVersion = "31.03.2020 15:00:00 V 1.0.0.0"
