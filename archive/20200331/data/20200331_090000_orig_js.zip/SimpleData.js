var Erkrankungen = 9705;
var LetzteAktualisierung = "31.03.2020 09:00.00";
