var Erkrankungen = "10109";
var LetzteAktualisierung = "31.03.2020 19:00.00";
var SimpleDataVersion = "31.03.2020 19:00:00 V 1.1.0.0"
