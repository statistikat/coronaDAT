var dpBundesland = [{"label":"Bgld","y":182},{"label":"Ktn","y":272},{"label":"NÖ","y":1597},{"label":"OÖ","y":1589},{"label":"Sbg","y":911},{"label":"Stmk","y":1035},{"label":"T","y":2323},{"label":"Vbg","y":641},{"label":"W","y":1370}];
var BundeslandVersion = "31.03.2020 14:00:00 V 1.0.0.0"
