var dpAltersverteilung = [{"label":"<5","y":41},{"label":"5-14","y":218},{"label":"15-24","y":936},{"label":"25-34","y":1487},{"label":"35-44","y":1493},{"label":"45-54","y":2161},{"label":"55-64","y":1756},{"label":">64","y":2049}];
var AltersverteilungVersion = "31.03.2020 21:00:00 V 1.1.0.0"
