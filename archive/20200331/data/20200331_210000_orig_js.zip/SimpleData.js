var Erkrankungen = "10141";
var LetzteAktualisierung = "31.03.2020 21:00.00";
var SimpleDataVersion = "31.03.2020 21:00:00 V 1.1.0.0"
