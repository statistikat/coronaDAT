var dpBundesland = [{"label":"W","y":1417},{"label":"Vbg","y":649},{"label":"T","y":2358},{"label":"Stmk","y":1063},{"label":"Sbg","y":924},{"label":"OÖ","y":1631},{"label":"NÖ","y":1636},{"label":"Ktn","y":278},{"label":"Bgld","y":185}];
var BundeslandVersion = "31.03.2020 21:00:00 V 1.1.0.0"
