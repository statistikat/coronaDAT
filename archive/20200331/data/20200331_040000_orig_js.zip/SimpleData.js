var Erkrankungen = 9618;
var LetzteAktualisierung = "31.03.2020 04:00.00";
