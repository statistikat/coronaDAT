var dpBundesland = [{"label":"W","y":1390},{"label":"Vbg","y":646},{"label":"T","y":2341},{"label":"Stmk","y":1055},{"label":"Sbg","y":917},{"label":"OÖ","y":1604},{"label":"NÖ","y":1631},{"label":"Ktn","y":272},{"label":"Bgld","y":182}];
var BundeslandVersion = "31.03.2020 17:00:00 V 1.1.0.0"
