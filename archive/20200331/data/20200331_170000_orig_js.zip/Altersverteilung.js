var dpAltersverteilung = [{"label":"<5","y":41},{"label":"5-14","y":214},{"label":"15-24","y":925},{"label":"25-34","y":1477},{"label":"35-44","y":1475},{"label":"45-54","y":2135},{"label":"55-64","y":1736},{"label":">64","y":2035}];
var AltersverteilungVersion = "31.03.2020 17:00:00 V 1.1.0.0"
