var Erkrankungen = 9772;
var LetzteAktualisierung = "31.03.2020 10:00.00";
