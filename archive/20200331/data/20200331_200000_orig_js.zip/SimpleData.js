var Erkrankungen = "10122";
var LetzteAktualisierung = "31.03.2020 20:00.00";
var SimpleDataVersion = "31.03.2020 20:00:00 V 1.1.0.0"
