var dpBundesland = [{"label":"W","y":1417},{"label":"Vbg","y":648},{"label":"T","y":2358},{"label":"Stmk","y":1063},{"label":"Sbg","y":923},{"label":"OÖ","y":1618},{"label":"NÖ","y":1633},{"label":"Ktn","y":277},{"label":"Bgld","y":185}];
var BundeslandVersion = "31.03.2020 20:00:00 V 1.1.0.0"
