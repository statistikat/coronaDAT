var dpGeschlechtsverteilung = [{"label":"männlich","y":52},{"label":"weiblich","y":48}];
var GeschlechtsverteilungVersion = "31.03.2020 12:00:00 V 1.0.0.0"
