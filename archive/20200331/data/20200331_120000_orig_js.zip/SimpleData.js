var Erkrankungen = "9851";
var LetzteAktualisierung = "31.03.2020 12:00.00";
var SimpleDataVersion = "31.03.2020 12:00:00 V 1.0.0.0"
