var dpBundesland = [{"label":"Bgld","y":181},{"label":"Ktn","y":270},{"label":"NÖ","y":1587},{"label":"OÖ","y":1575},{"label":"Sbg","y":910},{"label":"Stmk","y":1022},{"label":"T","y":2318},{"label":"Vbg","y":637},{"label":"W","y":1351}];
var BundeslandVersion = "31.03.2020 12:00:00 V 1.0.0.0"
