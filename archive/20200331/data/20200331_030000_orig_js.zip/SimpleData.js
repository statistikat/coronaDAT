var Erkrankungen = 9618;
var LetzteAktualisierung = "31.03.2020 03:00.00";
