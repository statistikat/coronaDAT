var dpGeschlechtsverteilung = [{"label":"männlich","y":53},{"label":"weiblich","y":47}];
