var Erkrankungen = 6909;
var LetzteAktualisierung = "27.03.2020 05:00.00";
