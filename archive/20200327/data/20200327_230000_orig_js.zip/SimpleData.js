var Erkrankungen = 7688;
var LetzteAktualisierung = "27.03.2020 23:00.00";
