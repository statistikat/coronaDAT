var Erkrankungen = 6909;
var LetzteAktualisierung = "27.03.2020 03:00.00";
