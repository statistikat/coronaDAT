var Erkrankungen = 6917;
var LetzteAktualisierung = "27.03.2020 07:00.00";
