var Erkrankungen = 7269;
var LetzteAktualisierung = "27.03.2020 12:00.00";
