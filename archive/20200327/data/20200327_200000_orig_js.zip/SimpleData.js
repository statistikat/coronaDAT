var Erkrankungen = 7657;
var LetzteAktualisierung = "27.03.2020 20:00.00";
