var Erkrankungen = 6909;
var LetzteAktualisierung = "27.03.2020 01:00.00";
