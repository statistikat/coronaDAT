var Erkrankungen = 7500;
var LetzteAktualisierung = "27.03.2020 16:00.00";
