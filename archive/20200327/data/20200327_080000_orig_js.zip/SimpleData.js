var Erkrankungen = 6962;
var LetzteAktualisierung = "27.03.2020 08:00.00";
