var Erkrankungen = 7642;
var LetzteAktualisierung = "27.03.2020 19:00.00";
