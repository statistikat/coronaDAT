var Erkrankungen = 6909;
var LetzteAktualisierung = "27.03.2020 04:00.00";
