var Erkrankungen = 7393;
var LetzteAktualisierung = "27.03.2020 14:00.00";
