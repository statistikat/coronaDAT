var Erkrankungen = 7129;
var LetzteAktualisierung = "27.03.2020 10:00.00";
