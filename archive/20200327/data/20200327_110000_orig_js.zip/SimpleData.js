var Erkrankungen = 7196;
var LetzteAktualisierung = "27.03.2020 11:00.00";
