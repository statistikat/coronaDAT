var Erkrankungen = 7441;
var LetzteAktualisierung = "27.03.2020 15:00.00";
