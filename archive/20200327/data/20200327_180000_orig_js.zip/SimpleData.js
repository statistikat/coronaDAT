var Erkrankungen = 7610;
var LetzteAktualisierung = "27.03.2020 18:00.00";
