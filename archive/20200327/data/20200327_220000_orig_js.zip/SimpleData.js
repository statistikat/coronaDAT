var Erkrankungen = 7672;
var LetzteAktualisierung = "27.03.2020 22:00.00";
