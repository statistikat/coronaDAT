var Erkrankungen = 7557;
var LetzteAktualisierung = "27.03.2020 17:00.00";
