var Erkrankungen = 6909;
var LetzteAktualisierung = "27.03.2020 06:00.00";
