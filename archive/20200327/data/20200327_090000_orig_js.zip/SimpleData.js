var Erkrankungen = 7029;
var LetzteAktualisierung = "27.03.2020 09:00.00";
