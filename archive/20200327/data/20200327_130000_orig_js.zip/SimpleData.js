var Erkrankungen = 7317;
var LetzteAktualisierung = "27.03.2020 13:00.00";
